   2:# 
   3:# ======= START RUNG 1 =======
   4:LabelRung1:
   5:
   6:set bit '$rung_top'
   8:# start series [
   9:# ELEM_CONTACTS
  10:if not 'X0' {
  11:    clear bit '$rung_top'
  12:}
  14:# ELEM_TON Tnew 5000000
  15:if '$rung_top' {
  16:    if 'Tnew' < '500' {
  17:        clear bit '$rung_top'
  18:        increment 'Tnew'
  19:    }
  20:} else {
  21:    let var 'Tnew' := 0
  22:}
  24:# ELEM_COIL
  25:let bit 'Y0' := '$rung_top'
  27:# ] finish series
  28:LabelRung2:
  29:
  30:# Latest INT_OP here
