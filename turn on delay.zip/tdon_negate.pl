   5:# 
   6:# ======= START RUNG 1 =======
   7:LabelRung1:
   8:
   9:set bit '$rung_top'
  11:# start series [
  12:# ELEM_CONTACTS
  13:if 'X0' {
  14:    clear bit '$rung_top'
  15:}
  17:# ELEM_TON T0 5000000
  18:if '$rung_top' {
  19:    if 'T0' < '500' {
  20:        clear bit '$rung_top'
  21:        increment 'T0'
  22:    }
  23:} else {
  24:    let var 'T0' := 0
  25:}
  27:# ELEM_COIL
  28:let bit 'Y0' := '$rung_top'
  30:# ] finish series
  31:# 
  32:# ======= START RUNG 2 =======
  33:LabelRung2:
  34:
  35:set bit '$rung_top'
  37:# start series [
  38:# ELEM_OPEN
  39:clear bit '$rung_top'
  41:# ELEM_COIL
  42:let bit 'Y1' := '$rung_top'
  44:# ] finish series
  45:# 
  46:# ======= START RUNG 3 =======
  47:LabelRung3:
  48:
  49:set bit '$rung_top'
  51:# start series [
  52:# ELEM_OPEN
  53:clear bit '$rung_top'
  55:# ELEM_COIL
  56:let bit 'Y2' := '$rung_top'
  58:# ] finish series
  59:# 
  60:# ======= START RUNG 4 =======
  61:LabelRung4:
  62:
  63:set bit '$rung_top'
  65:# start series [
  66:# ELEM_OPEN
  67:clear bit '$rung_top'
  69:# ELEM_COIL
  70:let bit 'Y3' := '$rung_top'
  72:# ] finish series
  73:LabelRung5:
  74:
  75:# Latest INT_OP here
