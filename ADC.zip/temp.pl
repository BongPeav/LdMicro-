   0:# INIT TABLES
   3:# 
   4:# ======= START RUNG 1 =======
   5:LabelRung1:
   6:
   7:set bit '$rung_top'
   9:# start series [
  10:# ELEM_FORMATTED_STRING
  11:if '$rung_top' {
  12:    if not '$once_0_FMTD_STR_' {
  13:        set bit '$once_0_FMTD_STR_'
  14:        let var '$fmtd_0_seq' := 0
  15:        set bit '$fmtd_3_doSend'
  16:    }
  17:} else {
  18:    clear bit '$once_0_FMTD_STR_'
  19:}
  20:let var '$seqScratch' := '$fmtd_0_seq'
  21:if '$fmtd_0_seq' < '12' {
  22:} else {
  23:    let var '$seqScratch' := -1
  24:}
  25:if '$fmtd_3_doSend' {
  26:    clear bit '$scratch'
  27:    '$scratch' = is uart ready to send ?
  28:    if not '$scratch' {
  29:        let var '$seqScratch' := -1
  30:    }
  31:}
  32:let var '$scratch' := 0
  33:if '$scratch' == '$seqScratch' {
  34:    let var '$charToUart' := 118
  35:}
  36:let var '$scratch' := 1
  37:if '$scratch' == '$seqScratch' {
  38:    let var '$charToUart' := 97
  39:}
  40:let var '$scratch' := 2
  41:if '$scratch' == '$seqScratch' {
  42:    let var '$charToUart' := 108
  43:}
  44:let var '$scratch' := 3
  45:if '$scratch' == '$seqScratch' {
  46:    let var '$charToUart' := 117
  47:}
  48:let var '$scratch' := 4
  49:if '$scratch' == '$seqScratch' {
  50:    let var '$charToUart' := 101
  51:}
  52:let var '$scratch' := 5
  53:if '$scratch' == '$seqScratch' {
  54:    let var '$charToUart' := 58
  55:}
  56:let var '$scratch' := 6
  57:if '$scratch' == '$seqScratch' {
  58:    let var '$charToUart' := 32
  59:}
  60:let var '$scratch' := 7
  61:clear bit '$scratch'
  62:if '$scratch' == '$seqScratch' {
  63:    set bit '$scratch'
  64:}
  65:if '$scratch' {
  66:    let var '$fmtd_1_convertState' := 'dest'
  67:    set bit '$fmtd_2_isLeadingZero'
  68:    let var '$scratch' := 100
  69:    let var '$charToUart' := '$fmtd_1_convertState' / '$scratch'
  70:    let var '$scratch' := '$scratch' * '$charToUart'
  71:    let var '$fmtd_1_convertState' := '$fmtd_1_convertState' - '$scratch'
  72:    let var '$scratch' := 48
  73:    let var '$charToUart' := '$charToUart' + '$scratch'
  74:    if '$scratch' == '$charToUart' {
  75:        if '$fmtd_2_isLeadingZero' {
  76:            let var '$charToUart' := 32
  77:        }
  78:    } else {
  79:        clear bit '$fmtd_2_isLeadingZero'
  80:    }
  81:}
  82:let var '$scratch' := 8
  83:clear bit '$scratch'
  84:if '$scratch' == '$seqScratch' {
  85:    set bit '$scratch'
  86:}
  87:if '$scratch' {
  88:    let var '$scratch' := 10
  89:    let var '$charToUart' := '$fmtd_1_convertState' / '$scratch'
  90:    let var '$scratch' := '$scratch' * '$charToUart'
  91:    let var '$fmtd_1_convertState' := '$fmtd_1_convertState' - '$scratch'
  92:    let var '$scratch' := 48
  93:    let var '$charToUart' := '$charToUart' + '$scratch'
  94:    if '$scratch' == '$charToUart' {
  95:        if '$fmtd_2_isLeadingZero' {
  96:            let var '$charToUart' := 32
  97:        }
  98:    } else {
  99:        clear bit '$fmtd_2_isLeadingZero'
 100:    }
 101:}
 102:let var '$scratch' := 9
 103:clear bit '$scratch'
 104:if '$scratch' == '$seqScratch' {
 105:    set bit '$scratch'
 106:}
 107:if '$scratch' {
 108:    let var '$scratch' := 1
 109:    let var '$charToUart' := '$fmtd_1_convertState' / '$scratch'
 110:    let var '$scratch' := '$scratch' * '$charToUart'
 111:    let var '$fmtd_1_convertState' := '$fmtd_1_convertState' - '$scratch'
 112:    let var '$scratch' := 48
 113:    let var '$charToUart' := '$charToUart' + '$scratch'
 114:}
 115:let var '$scratch' := 10
 116:if '$scratch' == '$seqScratch' {
 117:    let var '$charToUart' := 13
 118:}
 119:let var '$scratch' := 11
 120:if '$scratch' == '$seqScratch' {
 121:    let var '$charToUart' := 10
 122:}
 123:if '$seqScratch' < '0' {
 124:} else {
 125:    if '$fmtd_3_doSend' {
 126:        uart send from '$charToUart[+0]'
 127:        increment '$fmtd_0_seq'
 128:    }
 129:}
 130:clear bit '$rung_top'
 131:if '$fmtd_0_seq' < '12' {
 132:    if '$fmtd_3_doSend' {
 133:        set bit '$rung_top'
 134:    }
 135:} else {
 136:    clear bit '$fmtd_3_doSend'
 137:}
 139:# ] finish series
 140:LabelRung2:
 141:
 142:# Latest INT_OP here
