   0:# INIT TABLES
   3:# 
   4:# ======= START RUNG 1 =======
   5:LabelRung1:
   6:
   7:set bit '$rung_top'
   9:# start series [
  10:# ELEM_TCY T0 200000
  11:if '$rung_top' {
  12:    if 'T0' < '20' {
  13:        increment 'T0'
  14:    } else {
  15:        let var 'T0' := 0
  16:        if not '$once_0_TCY_T0' {
  17:            set bit '$once_0_TCY_T0'
  18:        } else {
  19:            clear bit '$once_0_TCY_T0'
  20:        }
  21:    }
  22:    if not '$once_0_TCY_T0' {
  23:        clear bit '$rung_top'
  24:    }
  25:} else {
  26:    let var 'T0' := 0
  27:}
  29:# ELEM_FORMATTED_STRING
  30:if '$rung_top' {
  31:    if not '$once_1_FMTD_STR_' {
  32:        set bit '$once_1_FMTD_STR_'
  33:        let var '$fmtd_0_seq' := 0
  34:        set bit '$fmtd_3_doSend'
  35:    }
  36:} else {
  37:    clear bit '$once_1_FMTD_STR_'
  38:}
  39:let var '$seqScratch' := '$fmtd_0_seq'
  40:if '$fmtd_0_seq' < '25' {
  41:} else {
  42:    let var '$seqScratch' := -1
  43:}
  44:if '$fmtd_3_doSend' {
  45:    clear bit '$scratch'
  46:    '$scratch' = is uart ready to send ?
  47:    if not '$scratch' {
  48:        let var '$seqScratch' := -1
  49:    }
  50:}
  51:let var '$scratch' := 0
  52:if '$scratch' == '$seqScratch' {
  53:    let var '$charToUart' := 65
  54:}
  55:let var '$scratch' := 1
  56:if '$scratch' == '$seqScratch' {
  57:    let var '$charToUart' := 68
  58:}
  59:let var '$scratch' := 2
  60:if '$scratch' == '$seqScratch' {
  61:    let var '$charToUart' := 67
  62:}
  63:let var '$scratch' := 3
  64:if '$scratch' == '$seqScratch' {
  65:    let var '$charToUart' := 32
  66:}
  67:let var '$scratch' := 4
  68:if '$scratch' == '$seqScratch' {
  69:    let var '$charToUart' := 118
  70:}
  71:let var '$scratch' := 5
  72:if '$scratch' == '$seqScratch' {
  73:    let var '$charToUart' := 97
  74:}
  75:let var '$scratch' := 6
  76:if '$scratch' == '$seqScratch' {
  77:    let var '$charToUart' := 108
  78:}
  79:let var '$scratch' := 7
  80:if '$scratch' == '$seqScratch' {
  81:    let var '$charToUart' := 117
  82:}
  83:let var '$scratch' := 8
  84:if '$scratch' == '$seqScratch' {
  85:    let var '$charToUart' := 101
  86:}
  87:let var '$scratch' := 9
  88:if '$scratch' == '$seqScratch' {
  89:    let var '$charToUart' := 32
  90:}
  91:let var '$scratch' := 10
  92:if '$scratch' == '$seqScratch' {
  93:    let var '$charToUart' := 111
  94:}
  95:let var '$scratch' := 11
  96:if '$scratch' == '$seqScratch' {
  97:    let var '$charToUart' := 102
  98:}
  99:let var '$scratch' := 12
 100:if '$scratch' == '$seqScratch' {
 101:    let var '$charToUart' := 32
 102:}
 103:let var '$scratch' := 13
 104:if '$scratch' == '$seqScratch' {
 105:    let var '$charToUart' := 82
 106:}
 107:let var '$scratch' := 14
 108:if '$scratch' == '$seqScratch' {
 109:    let var '$charToUart' := 65
 110:}
 111:let var '$scratch' := 15
 112:if '$scratch' == '$seqScratch' {
 113:    let var '$charToUart' := 48
 114:}
 115:let var '$scratch' := 16
 116:if '$scratch' == '$seqScratch' {
 117:    let var '$charToUart' := 32
 118:}
 119:let var '$scratch' := 17
 120:if '$scratch' == '$seqScratch' {
 121:    let var '$charToUart' := 58
 122:}
 123:let var '$scratch' := 18
 124:if '$scratch' == '$seqScratch' {
 125:    let var '$charToUart' := 32
 126:}
 127:let var '$scratch' := 19
 128:clear bit '$scratch'
 129:if '$scratch' == '$seqScratch' {
 130:    set bit '$scratch'
 131:}
 132:if '$scratch' {
 133:    let var '$fmtd_1_convertState' := 'ACH0'
 134:    set bit '$fmtd_2_isLeadingZero'
 135:    let var '$scratch' := 1000
 136:    let var '$charToUart' := '$fmtd_1_convertState' / '$scratch'
 137:    let var '$scratch' := '$scratch' * '$charToUart'
 138:    let var '$fmtd_1_convertState' := '$fmtd_1_convertState' - '$scratch'
 139:    let var '$scratch' := 48
 140:    let var '$charToUart' := '$charToUart' + '$scratch'
 141:    if '$scratch' == '$charToUart' {
 142:        if '$fmtd_2_isLeadingZero' {
 143:            let var '$charToUart' := 32
 144:        }
 145:    } else {
 146:        clear bit '$fmtd_2_isLeadingZero'
 147:    }
 148:}
 149:let var '$scratch' := 20
 150:clear bit '$scratch'
 151:if '$scratch' == '$seqScratch' {
 152:    set bit '$scratch'
 153:}
 154:if '$scratch' {
 155:    let var '$scratch' := 100
 156:    let var '$charToUart' := '$fmtd_1_convertState' / '$scratch'
 157:    let var '$scratch' := '$scratch' * '$charToUart'
 158:    let var '$fmtd_1_convertState' := '$fmtd_1_convertState' - '$scratch'
 159:    let var '$scratch' := 48
 160:    let var '$charToUart' := '$charToUart' + '$scratch'
 161:    if '$scratch' == '$charToUart' {
 162:        if '$fmtd_2_isLeadingZero' {
 163:            let var '$charToUart' := 32
 164:        }
 165:    } else {
 166:        clear bit '$fmtd_2_isLeadingZero'
 167:    }
 168:}
 169:let var '$scratch' := 21
 170:clear bit '$scratch'
 171:if '$scratch' == '$seqScratch' {
 172:    set bit '$scratch'
 173:}
 174:if '$scratch' {
 175:    let var '$scratch' := 10
 176:    let var '$charToUart' := '$fmtd_1_convertState' / '$scratch'
 177:    let var '$scratch' := '$scratch' * '$charToUart'
 178:    let var '$fmtd_1_convertState' := '$fmtd_1_convertState' - '$scratch'
 179:    let var '$scratch' := 48
 180:    let var '$charToUart' := '$charToUart' + '$scratch'
 181:    if '$scratch' == '$charToUart' {
 182:        if '$fmtd_2_isLeadingZero' {
 183:            let var '$charToUart' := 32
 184:        }
 185:    } else {
 186:        clear bit '$fmtd_2_isLeadingZero'
 187:    }
 188:}
 189:let var '$scratch' := 22
 190:clear bit '$scratch'
 191:if '$scratch' == '$seqScratch' {
 192:    set bit '$scratch'
 193:}
 194:if '$scratch' {
 195:    let var '$scratch' := 1
 196:    let var '$charToUart' := '$fmtd_1_convertState' / '$scratch'
 197:    let var '$scratch' := '$scratch' * '$charToUart'
 198:    let var '$fmtd_1_convertState' := '$fmtd_1_convertState' - '$scratch'
 199:    let var '$scratch' := 48
 200:    let var '$charToUart' := '$charToUart' + '$scratch'
 201:}
 202:let var '$scratch' := 23
 203:if '$scratch' == '$seqScratch' {
 204:    let var '$charToUart' := 13
 205:}
 206:let var '$scratch' := 24
 207:if '$scratch' == '$seqScratch' {
 208:    let var '$charToUart' := 10
 209:}
 210:if '$seqScratch' < '0' {
 211:} else {
 212:    if '$fmtd_3_doSend' {
 213:        uart send from '$charToUart[+0]'
 214:        increment '$fmtd_0_seq'
 215:    }
 216:}
 217:clear bit '$rung_top'
 218:if '$fmtd_0_seq' < '25' {
 219:    if '$fmtd_3_doSend' {
 220:        set bit '$rung_top'
 221:    }
 222:} else {
 223:    clear bit '$fmtd_3_doSend'
 224:}
 226:# ELEM_READ_ADC
 227:if '$rung_top' {
 228:    read adc 'ACH0', refs is '0'
 229:}
 231:# ] finish series
 232:LabelRung2:
 233:
 234:# Latest INT_OP here
