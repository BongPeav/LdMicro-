   0:# INIT VARS
   1:if not '$once_0_INIT_VARS' {
   2:    set bit '$once_0_INIT_VARS'
   3:    let var 'T0' := 1000
   4:}
  10:# 
  11:# ======= START RUNG 1 =======
  12:LabelRung1:
  13:
  14:set bit '$rung_top'
  16:# start series [
  17:# ELEM_ONE_SHOT_RISING
  18:if '$rung_top' {
  19:    if '$once_1_ONE_SHOT_RISING_' {
  20:        clear bit '$rung_top'
  21:    } else {
  22:        set bit '$once_1_ONE_SHOT_RISING_'
  23:    }
  24:} else {
  25:    clear bit '$once_1_ONE_SHOT_RISING_'
  26:}
  28:# ELEM_TOF
  29:if not '$rung_top' {
  30:    if 'T0' < '1000' {
  31:        increment 'T0'
  32:        set bit '$rung_top'
  33:    }
  34:} else {
  35:    let var 'T0' := 0
  36:}
  38:# ELEM_COIL
  39:let bit 'Y0' := '$rung_top'
  41:# ] finish series
  42:# 
  43:# ======= START RUNG 2 =======
  44:LabelRung2:
  45:
  46:set bit '$rung_top'
  48:# start series [
  49:# ELEM_OPEN
  50:clear bit '$rung_top'
  52:# ELEM_COIL
  53:let bit 'Y1' := '$rung_top'
  55:# ] finish series
  56:# 
  57:# ======= START RUNG 3 =======
  58:LabelRung3:
  59:
  60:set bit '$rung_top'
  62:# start series [
  63:# ELEM_OPEN
  64:clear bit '$rung_top'
  66:# ELEM_COIL
  67:let bit 'Y2' := '$rung_top'
  69:# ] finish series
  70:# 
  71:# ======= START RUNG 4 =======
  72:LabelRung4:
  73:
  74:set bit '$rung_top'
  76:# start series [
  77:# ELEM_OPEN
  78:clear bit '$rung_top'
  80:# ELEM_COIL
  81:let bit 'Y3' := '$rung_top'
  83:# ] finish series
  84:LabelRung5:
  85:
  86:# Latest INT_OP here
