   4:# 
   5:# ======= START RUNG 1 =======
   6:LabelRung1:
   7:
   8:set bit '$rung_top'
  10:# start series [
  11:# ELEM_CONTACTS
  12:if 'X0' {
  13:    clear bit '$rung_top'
  14:}
  16:# ELEM_COIL
  17:if '$rung_top' {
  18:    if not '$once_0_TTRIGGER_Ron' {
  19:        set bit '$once_0_TTRIGGER_Ron'
  20:        if 'Ron' {
  21:            clear bit 'Ron'
  22:        } else {
  23:            set bit 'Ron'
  24:        }
  25:    }
  26:} else {
  27:    clear bit '$once_0_TTRIGGER_Ron'
  28:}
  30:# ] finish series
  31:# 
  32:# ======= START RUNG 2 =======
  33:LabelRung2:
  34:
  35:set bit '$rung_top'
  37:# start series [
  38:# ELEM_CONTACTS
  39:if 'Ron' {
  40:    clear bit '$rung_top'
  41:}
  43:# ELEM_RES
  44:if '$rung_top' {
  45:    pwm off 'P1'
  46:    clear bit '$P1'
  47:}
  49:# ] finish series
  50:# 
  51:# ======= START RUNG 3 =======
  52:LabelRung3:
  53:
  54:set bit '$rung_top'
  56:# start series [
  57:# ELEM_CONTACTS
  58:if not 'Ron' {
  59:    clear bit '$rung_top'
  60:}
  62:# ELEM_SET_PWM
  63:if '$rung_top' {
  64:    set pwm '80' % 10000 Hz out 'P1'
  65:    set bit '$P1'
  66:}
  68:# ] finish series
  69:LabelRung4:
  70:
  71:# Latest INT_OP here
