   5:# 
   6:# ======= START RUNG 1 =======
   7:LabelRung1:
   8:
   9:set bit '$rung_top'
  11:# start series [
  12:# ELEM_ONE_SHOT_RISING
  13:if '$rung_top' {
  14:    if '$once_0_ONE_SHOT_RISING_' {
  15:        clear bit '$rung_top'
  16:    } else {
  17:        set bit '$once_0_ONE_SHOT_RISING_'
  18:    }
  19:} else {
  20:    clear bit '$once_0_ONE_SHOT_RISING_'
  21:}
  23:# ELEM_MOVE
  24:if '$rung_top' {
  25:    let var 'pwmDuty' := 0
  26:}
  28:# ] finish series
  29:# 
  30:# ======= START RUNG 2 =======
  31:LabelRung2:
  32:
  33:set bit '$rung_top'
  35:# start series [
  36:# ELEM_CONTACTS
  37:if 'Xinc' {
  38:    clear bit '$rung_top'
  39:}
  41:# ELEM_LES
  42:if '$rung_top' {
  43:    if 'pwmDuty' >= '100' {
  44:        clear bit '$rung_top'
  45:    }
  46:}
  48:# ELEM_ONE_SHOT_RISING
  49:if '$rung_top' {
  50:    if '$once_1_ONE_SHOT_RISING_' {
  51:        clear bit '$rung_top'
  52:    } else {
  53:        set bit '$once_1_ONE_SHOT_RISING_'
  54:    }
  55:} else {
  56:    clear bit '$once_1_ONE_SHOT_RISING_'
  57:}
  59:# ELEM_ADD
  60:if '$rung_top' {
  61:    let var '$scratch2' := 10
  62:    let var 'pwmDuty' := 'pwmDuty' + '$scratch2'; copy overflow flag to '$overlap'
  63:}
  65:# ] finish series
  66:# 
  67:# ======= START RUNG 3 =======
  68:LabelRung3:
  69:
  70:set bit '$rung_top'
  72:# start series [
  73:# ELEM_CONTACTS
  74:if 'Xdec' {
  75:    clear bit '$rung_top'
  76:}
  78:# ELEM_GRT
  79:if '$rung_top' {
  80:    if 'pwmDuty' <= '0' {
  81:        clear bit '$rung_top'
  82:    }
  83:}
  85:# ELEM_ONE_SHOT_RISING
  86:if '$rung_top' {
  87:    if '$once_2_ONE_SHOT_RISING_' {
  88:        clear bit '$rung_top'
  89:    } else {
  90:        set bit '$once_2_ONE_SHOT_RISING_'
  91:    }
  92:} else {
  93:    clear bit '$once_2_ONE_SHOT_RISING_'
  94:}
  96:# ELEM_SUB
  97:if '$rung_top' {
  98:    let var '$scratch2' := 10
  99:    let var 'pwmDuty' := 'pwmDuty' - '$scratch2'; copy overflow flag to '$overlap'
 100:}
 102:# ] finish series
 103:# 
 104:# ======= START RUNG 4 =======
 105:LabelRung4:
 106:
 107:set bit '$rung_top'
 109:# start series [
 110:# ELEM_SET_PWM
 111:if '$rung_top' {
 112:    set pwm 'pwmDuty' % 10000 Hz out 'PWMoutpin'
 113:    set bit '$PWMoutpin'
 114:}
 116:# ] finish series
 117:LabelRung5:
 118:
 119:# Latest INT_OP here
