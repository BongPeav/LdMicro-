   0:# INIT TABLES
   7:# 
   8:# ======= START RUNG 1 =======
   9:LabelRung1:
  10:
  11:set bit '$rung_top'
  13:# start series [
  14:# ELEM_TCY T0 500000
  15:if '$rung_top' {
  16:    if 'T0' < '50' {
  17:        increment 'T0'
  18:    } else {
  19:        let var 'T0' := 0
  20:        if not '$once_0_TCY_T0' {
  21:            set bit '$once_0_TCY_T0'
  22:        } else {
  23:            clear bit '$once_0_TCY_T0'
  24:        }
  25:    }
  26:    if not '$once_0_TCY_T0' {
  27:        clear bit '$rung_top'
  28:    }
  29:} else {
  30:    let var 'T0' := 0
  31:}
  33:# ELEM_COIL
  34:let bit 'Ready' := '$rung_top'
  36:# ] finish series
  37:# 
  38:# ======= START RUNG 2 =======
  39:LabelRung2:
  40:
  41:set bit '$rung_top'
  43:# start series [
  44:# ELEM_CONTACTS
  45:if not 'Ready' {
  46:    clear bit '$rung_top'
  47:}
  49:# ELEM_READ_ADC
  50:if '$rung_top' {
  51:    read adc 'ADC0', refs is '0'
  52:}
  54:# ] finish series
  55:# 
  56:# ======= START RUNG 3 =======
  57:LabelRung3:
  58:
  59:set bit '$rung_top'
  61:# start series [
  62:# ELEM_PIECEWISE_LINEAR
  63:if '$rung_top' {
  64:    # PWL 2
  65:    clear bit '$scratch'
  66:    if 'ADC0' < '301' {
  67:        set bit '$scratch'
  68:    }
  69:    if '$scratch' {
  70:        let var 'data' := 'ADC0' - '150'
  71:        let var 'data' := 'data' * '75'
  72:        let var 'data' := 'data' / '150'
  73:        let var 'data' := 'data' + '75'
  74:    }
  75:    # PWL 1
  76:    clear bit '$scratch'
  77:    if 'ADC0' < '151' {
  78:        set bit '$scratch'
  79:    }
  80:    if '$scratch' {
  81:        let var 'data' := 'ADC0' - '0'
  82:        let var 'data' := 'data' * '75'
  83:        let var 'data' := 'data' / '150'
  84:        let var 'data' := 'data' + '0'
  85:    }
  86:}
  88:# ] finish series
  89:# 
  90:# ======= START RUNG 4 =======
  91:LabelRung4:
  92:
  93:set bit '$rung_top'
  95:# start series [
  96:# ELEM_CONTACTS
  97:if not 'Ready' {
  98:    clear bit '$rung_top'
  99:}
 101:# ELEM_FORMATTED_STRING
 102:if '$rung_top' {
 103:    if not '$once_1_FMTD_STR_' {
 104:        set bit '$once_1_FMTD_STR_'
 105:        let var '$fmtd_0_seq' := 0
 106:        set bit '$fmtd_3_doSend'
 107:    }
 108:} else {
 109:    clear bit '$once_1_FMTD_STR_'
 110:}
 111:let var '$seqScratch' := '$fmtd_0_seq'
 112:if '$fmtd_0_seq' < '28' {
 113:} else {
 114:    let var '$seqScratch' := -1
 115:}
 116:if '$fmtd_3_doSend' {
 117:    clear bit '$scratch'
 118:    '$scratch' = is uart ready to send ?
 119:    if not '$scratch' {
 120:        let var '$seqScratch' := -1
 121:    }
 122:}
 123:let var '$scratch' := 0
 124:if '$scratch' == '$seqScratch' {
 125:    let var '$charToUart' := 116
 126:}
 127:let var '$scratch' := 1
 128:if '$scratch' == '$seqScratch' {
 129:    let var '$charToUart' := 101
 130:}
 131:let var '$scratch' := 2
 132:if '$scratch' == '$seqScratch' {
 133:    let var '$charToUart' := 109
 134:}
 135:let var '$scratch' := 3
 136:if '$scratch' == '$seqScratch' {
 137:    let var '$charToUart' := 112
 138:}
 139:let var '$scratch' := 4
 140:if '$scratch' == '$seqScratch' {
 141:    let var '$charToUart' := 101
 142:}
 143:let var '$scratch' := 5
 144:if '$scratch' == '$seqScratch' {
 145:    let var '$charToUart' := 114
 146:}
 147:let var '$scratch' := 6
 148:if '$scratch' == '$seqScratch' {
 149:    let var '$charToUart' := 97
 150:}
 151:let var '$scratch' := 7
 152:if '$scratch' == '$seqScratch' {
 153:    let var '$charToUart' := 116
 154:}
 155:let var '$scratch' := 8
 156:if '$scratch' == '$seqScratch' {
 157:    let var '$charToUart' := 117
 158:}
 159:let var '$scratch' := 9
 160:if '$scratch' == '$seqScratch' {
 161:    let var '$charToUart' := 114
 162:}
 163:let var '$scratch' := 10
 164:if '$scratch' == '$seqScratch' {
 165:    let var '$charToUart' := 101
 166:}
 167:let var '$scratch' := 11
 168:if '$scratch' == '$seqScratch' {
 169:    let var '$charToUart' := 32
 170:}
 171:let var '$scratch' := 12
 172:if '$scratch' == '$seqScratch' {
 173:    let var '$charToUart' := 102
 174:}
 175:let var '$scratch' := 13
 176:if '$scratch' == '$seqScratch' {
 177:    let var '$charToUart' := 114
 178:}
 179:let var '$scratch' := 14
 180:if '$scratch' == '$seqScratch' {
 181:    let var '$charToUart' := 111
 182:}
 183:let var '$scratch' := 15
 184:if '$scratch' == '$seqScratch' {
 185:    let var '$charToUart' := 109
 186:}
 187:let var '$scratch' := 16
 188:if '$scratch' == '$seqScratch' {
 189:    let var '$charToUart' := 32
 190:}
 191:let var '$scratch' := 17
 192:if '$scratch' == '$seqScratch' {
 193:    let var '$charToUart' := 76
 194:}
 195:let var '$scratch' := 18
 196:if '$scratch' == '$seqScratch' {
 197:    let var '$charToUart' := 77
 198:}
 199:let var '$scratch' := 19
 200:if '$scratch' == '$seqScratch' {
 201:    let var '$charToUart' := 51
 202:}
 203:let var '$scratch' := 20
 204:if '$scratch' == '$seqScratch' {
 205:    let var '$charToUart' := 53
 206:}
 207:let var '$scratch' := 21
 208:if '$scratch' == '$seqScratch' {
 209:    let var '$charToUart' := 58
 210:}
 211:let var '$scratch' := 22
 212:if '$scratch' == '$seqScratch' {
 213:    let var '$charToUart' := 32
 214:}
 215:let var '$scratch' := 23
 216:clear bit '$scratch'
 217:if '$scratch' == '$seqScratch' {
 218:    set bit '$scratch'
 219:}
 220:if '$scratch' {
 221:    let var '$fmtd_1_convertState' := 'data'
 222:    set bit '$fmtd_2_isLeadingZero'
 223:    let var '$scratch' := 100
 224:    let var '$charToUart' := '$fmtd_1_convertState' / '$scratch'
 225:    let var '$scratch' := '$scratch' * '$charToUart'
 226:    let var '$fmtd_1_convertState' := '$fmtd_1_convertState' - '$scratch'
 227:    let var '$scratch' := 48
 228:    let var '$charToUart' := '$charToUart' + '$scratch'
 229:    if '$scratch' == '$charToUart' {
 230:        if '$fmtd_2_isLeadingZero' {
 231:            let var '$charToUart' := 32
 232:        }
 233:    } else {
 234:        clear bit '$fmtd_2_isLeadingZero'
 235:    }
 236:}
 237:let var '$scratch' := 24
 238:clear bit '$scratch'
 239:if '$scratch' == '$seqScratch' {
 240:    set bit '$scratch'
 241:}
 242:if '$scratch' {
 243:    let var '$scratch' := 10
 244:    let var '$charToUart' := '$fmtd_1_convertState' / '$scratch'
 245:    let var '$scratch' := '$scratch' * '$charToUart'
 246:    let var '$fmtd_1_convertState' := '$fmtd_1_convertState' - '$scratch'
 247:    let var '$scratch' := 48
 248:    let var '$charToUart' := '$charToUart' + '$scratch'
 249:    if '$scratch' == '$charToUart' {
 250:        if '$fmtd_2_isLeadingZero' {
 251:            let var '$charToUart' := 32
 252:        }
 253:    } else {
 254:        clear bit '$fmtd_2_isLeadingZero'
 255:    }
 256:}
 257:let var '$scratch' := 25
 258:clear bit '$scratch'
 259:if '$scratch' == '$seqScratch' {
 260:    set bit '$scratch'
 261:}
 262:if '$scratch' {
 263:    let var '$scratch' := 1
 264:    let var '$charToUart' := '$fmtd_1_convertState' / '$scratch'
 265:    let var '$scratch' := '$scratch' * '$charToUart'
 266:    let var '$fmtd_1_convertState' := '$fmtd_1_convertState' - '$scratch'
 267:    let var '$scratch' := 48
 268:    let var '$charToUart' := '$charToUart' + '$scratch'
 269:}
 270:let var '$scratch' := 26
 271:if '$scratch' == '$seqScratch' {
 272:    let var '$charToUart' := 13
 273:}
 274:let var '$scratch' := 27
 275:if '$scratch' == '$seqScratch' {
 276:    let var '$charToUart' := 10
 277:}
 278:if '$seqScratch' < '0' {
 279:} else {
 280:    if '$fmtd_3_doSend' {
 281:        uart send from '$charToUart[+0]'
 282:        increment '$fmtd_0_seq'
 283:    }
 284:}
 285:clear bit '$rung_top'
 286:if '$fmtd_0_seq' < '28' {
 287:    if '$fmtd_3_doSend' {
 288:        set bit '$rung_top'
 289:    }
 290:} else {
 291:    clear bit '$fmtd_3_doSend'
 292:}
 294:# ] finish series
 295:# 
 296:# ======= START RUNG 5 =======
 297:LabelRung5:
 298:
 299:set bit '$rung_top'
 301:# start series [
 302:# ELEM_GRT
 303:if '$rung_top' {
 304:    if 'data' <= '40' {
 305:        clear bit '$rung_top'
 306:    }
 307:}
 309:# ELEM_COIL
 310:let bit 'Yalert' := '$rung_top'
 312:# ] finish series
 313:LabelRung6:
 314:
 315:# Latest INT_OP here
