   3:# 
   4:# ======= START RUNG 1 =======
   5:LabelRung1:
   6:
   7:set bit '$rung_top'
   9:# start series [
  10:# ELEM_ONE_SHOT_LOW
  11:if not '$rung_top' {
  12:    let bit '$rung_top' := '$once_0_ONE_SHOT_LOW_'
  13:    if '$once_1_ONE_SHOT_HI_' {
  14:        if not '$once_0_ONE_SHOT_LOW_' {
  15:            set bit '$once_0_ONE_SHOT_LOW_'
  16:        }
  17:    }
  18:} else {
  19:    clear bit '$once_0_ONE_SHOT_LOW_'
  20:    set bit '$once_1_ONE_SHOT_HI_'
  21:}
  23:# ELEM_COIL
  24:let bit 'Y0' := '$rung_top'
  26:# ] finish series
  27:# 
  28:# ======= START RUNG 2 =======
  29:LabelRung2:
  30:
  31:set bit '$rung_top'
  33:# start series [
  34:# ELEM_CONTACTS
  35:if not 'X0' {
  36:    clear bit '$rung_top'
  37:}
  39:# ELEM_ONE_SHOT_LOW
  40:if not '$rung_top' {
  41:    let bit '$rung_top' := '$once_2_ONE_SHOT_LOW_'
  42:    if '$once_3_ONE_SHOT_HI_' {
  43:        if not '$once_2_ONE_SHOT_LOW_' {
  44:            set bit '$once_2_ONE_SHOT_LOW_'
  45:        }
  46:    }
  47:} else {
  48:    clear bit '$once_2_ONE_SHOT_LOW_'
  49:    set bit '$once_3_ONE_SHOT_HI_'
  50:}
  52:# ELEM_COIL
  53:let bit 'Y1' := '$rung_top'
  55:# ] finish series
  56:LabelRung3:
  57:
  58:# Latest INT_OP here
