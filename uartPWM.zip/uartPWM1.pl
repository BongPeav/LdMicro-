   0:# INIT TABLES
   6:# 
   7:# ======= START RUNG 1 =======
   8:LabelRung1:
   9:
  10:set bit '$rung_top'
  12:# start series [
  13:# ELEM_ONE_SHOT_RISING
  14:if '$rung_top' {
  15:    if '$once_0_ONE_SHOT_RISING_' {
  16:        clear bit '$rung_top'
  17:    } else {
  18:        set bit '$once_0_ONE_SHOT_RISING_'
  19:    }
  20:} else {
  21:    clear bit '$once_0_ONE_SHOT_RISING_'
  22:}
  24:# ELEM_MOVE
  25:if '$rung_top' {
  26:    let var 'duty' := 0
  27:}
  29:# ] finish series
  30:# 
  31:# ======= START RUNG 2 =======
  32:LabelRung2:
  33:
  34:set bit '$rung_top'
  36:# start series [
  37:# ELEM_FORMATTED_STRING
  38:if '$rung_top' {
  39:    if not '$once_1_FMTD_STR_' {
  40:        set bit '$once_1_FMTD_STR_'
  41:        let var '$fmtd_0_seq' := 0
  42:        set bit '$fmtd_3_doSend'
  43:    }
  44:} else {
  45:    clear bit '$once_1_FMTD_STR_'
  46:}
  47:let var '$seqScratch' := '$fmtd_0_seq'
  48:if '$fmtd_0_seq' < '56' {
  49:} else {
  50:    let var '$seqScratch' := -1
  51:}
  52:if '$fmtd_3_doSend' {
  53:    clear bit '$scratch'
  54:    '$scratch' = is uart ready to send ?
  55:    if not '$scratch' {
  56:        let var '$seqScratch' := -1
  57:    }
  58:}
  59:let var '$scratch' := 0
  60:if '$scratch' == '$seqScratch' {
  61:    let var '$charToUart' := 80
  62:}
  63:let var '$scratch' := 1
  64:if '$scratch' == '$seqScratch' {
  65:    let var '$charToUart' := 82
  66:}
  67:let var '$scratch' := 2
  68:if '$scratch' == '$seqScratch' {
  69:    let var '$charToUart' := 69
  70:}
  71:let var '$scratch' := 3
  72:if '$scratch' == '$seqScratch' {
  73:    let var '$charToUart' := 83
  74:}
  75:let var '$scratch' := 4
  76:if '$scratch' == '$seqScratch' {
  77:    let var '$charToUart' := 83
  78:}
  79:let var '$scratch' := 5
  80:if '$scratch' == '$seqScratch' {
  81:    let var '$charToUart' := 32
  82:}
  83:let var '$scratch' := 6
  84:if '$scratch' == '$seqScratch' {
  85:    let var '$charToUart' := 39
  86:}
  87:let var '$scratch' := 7
  88:if '$scratch' == '$seqScratch' {
  89:    let var '$charToUart' := 80
  90:}
  91:let var '$scratch' := 8
  92:if '$scratch' == '$seqScratch' {
  93:    let var '$charToUart' := 39
  94:}
  95:let var '$scratch' := 9
  96:if '$scratch' == '$seqScratch' {
  97:    let var '$charToUart' := 32
  98:}
  99:let var '$scratch' := 10
 100:if '$scratch' == '$seqScratch' {
 101:    let var '$charToUart' := 84
 102:}
 103:let var '$scratch' := 11
 104:if '$scratch' == '$seqScratch' {
 105:    let var '$charToUart' := 79
 106:}
 107:let var '$scratch' := 12
 108:if '$scratch' == '$seqScratch' {
 109:    let var '$charToUart' := 32
 110:}
 111:let var '$scratch' := 13
 112:if '$scratch' == '$seqScratch' {
 113:    let var '$charToUart' := 73
 114:}
 115:let var '$scratch' := 14
 116:if '$scratch' == '$seqScratch' {
 117:    let var '$charToUart' := 78
 118:}
 119:let var '$scratch' := 15
 120:if '$scratch' == '$seqScratch' {
 121:    let var '$charToUart' := 67
 122:}
 123:let var '$scratch' := 16
 124:if '$scratch' == '$seqScratch' {
 125:    let var '$charToUart' := 82
 126:}
 127:let var '$scratch' := 17
 128:if '$scratch' == '$seqScratch' {
 129:    let var '$charToUart' := 69
 130:}
 131:let var '$scratch' := 18
 132:if '$scratch' == '$seqScratch' {
 133:    let var '$charToUart' := 65
 134:}
 135:let var '$scratch' := 19
 136:if '$scratch' == '$seqScratch' {
 137:    let var '$charToUart' := 83
 138:}
 139:let var '$scratch' := 20
 140:if '$scratch' == '$seqScratch' {
 141:    let var '$charToUart' := 69
 142:}
 143:let var '$scratch' := 21
 144:if '$scratch' == '$seqScratch' {
 145:    let var '$charToUart' := 32
 146:}
 147:let var '$scratch' := 22
 148:if '$scratch' == '$seqScratch' {
 149:    let var '$charToUart' := 68
 150:}
 151:let var '$scratch' := 23
 152:if '$scratch' == '$seqScratch' {
 153:    let var '$charToUart' := 85
 154:}
 155:let var '$scratch' := 24
 156:if '$scratch' == '$seqScratch' {
 157:    let var '$charToUart' := 84
 158:}
 159:let var '$scratch' := 25
 160:if '$scratch' == '$seqScratch' {
 161:    let var '$charToUart' := 89
 162:}
 163:let var '$scratch' := 26
 164:if '$scratch' == '$seqScratch' {
 165:    let var '$charToUart' := 13
 166:}
 167:let var '$scratch' := 27
 168:if '$scratch' == '$seqScratch' {
 169:    let var '$charToUart' := 10
 170:}
 171:let var '$scratch' := 28
 172:if '$scratch' == '$seqScratch' {
 173:    let var '$charToUart' := 80
 174:}
 175:let var '$scratch' := 29
 176:if '$scratch' == '$seqScratch' {
 177:    let var '$charToUart' := 82
 178:}
 179:let var '$scratch' := 30
 180:if '$scratch' == '$seqScratch' {
 181:    let var '$charToUart' := 69
 182:}
 183:let var '$scratch' := 31
 184:if '$scratch' == '$seqScratch' {
 185:    let var '$charToUart' := 83
 186:}
 187:let var '$scratch' := 32
 188:if '$scratch' == '$seqScratch' {
 189:    let var '$charToUart' := 83
 190:}
 191:let var '$scratch' := 33
 192:if '$scratch' == '$seqScratch' {
 193:    let var '$charToUart' := 32
 194:}
 195:let var '$scratch' := 34
 196:if '$scratch' == '$seqScratch' {
 197:    let var '$charToUart' := 39
 198:}
 199:let var '$scratch' := 35
 200:if '$scratch' == '$seqScratch' {
 201:    let var '$charToUart' := 77
 202:}
 203:let var '$scratch' := 36
 204:if '$scratch' == '$seqScratch' {
 205:    let var '$charToUart' := 39
 206:}
 207:let var '$scratch' := 37
 208:if '$scratch' == '$seqScratch' {
 209:    let var '$charToUart' := 32
 210:}
 211:let var '$scratch' := 38
 212:if '$scratch' == '$seqScratch' {
 213:    let var '$charToUart' := 84
 214:}
 215:let var '$scratch' := 39
 216:if '$scratch' == '$seqScratch' {
 217:    let var '$charToUart' := 79
 218:}
 219:let var '$scratch' := 40
 220:if '$scratch' == '$seqScratch' {
 221:    let var '$charToUart' := 32
 222:}
 223:let var '$scratch' := 41
 224:if '$scratch' == '$seqScratch' {
 225:    let var '$charToUart' := 68
 226:}
 227:let var '$scratch' := 42
 228:if '$scratch' == '$seqScratch' {
 229:    let var '$charToUart' := 69
 230:}
 231:let var '$scratch' := 43
 232:if '$scratch' == '$seqScratch' {
 233:    let var '$charToUart' := 67
 234:}
 235:let var '$scratch' := 44
 236:if '$scratch' == '$seqScratch' {
 237:    let var '$charToUart' := 82
 238:}
 239:let var '$scratch' := 45
 240:if '$scratch' == '$seqScratch' {
 241:    let var '$charToUart' := 69
 242:}
 243:let var '$scratch' := 46
 244:if '$scratch' == '$seqScratch' {
 245:    let var '$charToUart' := 65
 246:}
 247:let var '$scratch' := 47
 248:if '$scratch' == '$seqScratch' {
 249:    let var '$charToUart' := 83
 250:}
 251:let var '$scratch' := 48
 252:if '$scratch' == '$seqScratch' {
 253:    let var '$charToUart' := 69
 254:}
 255:let var '$scratch' := 49
 256:if '$scratch' == '$seqScratch' {
 257:    let var '$charToUart' := 32
 258:}
 259:let var '$scratch' := 50
 260:if '$scratch' == '$seqScratch' {
 261:    let var '$charToUart' := 68
 262:}
 263:let var '$scratch' := 51
 264:if '$scratch' == '$seqScratch' {
 265:    let var '$charToUart' := 85
 266:}
 267:let var '$scratch' := 52
 268:if '$scratch' == '$seqScratch' {
 269:    let var '$charToUart' := 84
 270:}
 271:let var '$scratch' := 53
 272:if '$scratch' == '$seqScratch' {
 273:    let var '$charToUart' := 89
 274:}
 275:let var '$scratch' := 54
 276:if '$scratch' == '$seqScratch' {
 277:    let var '$charToUart' := 13
 278:}
 279:let var '$scratch' := 55
 280:if '$scratch' == '$seqScratch' {
 281:    let var '$charToUart' := 10
 282:}
 283:if '$seqScratch' < '0' {
 284:} else {
 285:    if '$fmtd_3_doSend' {
 286:        uart send from '$charToUart[+0]'
 287:        increment '$fmtd_0_seq'
 288:    }
 289:}
 290:clear bit '$rung_top'
 291:if '$fmtd_0_seq' < '56' {
 292:    if '$fmtd_3_doSend' {
 293:        set bit '$rung_top'
 294:    }
 295:} else {
 296:    clear bit '$fmtd_3_doSend'
 297:}
 299:# ] finish series
 300:# 
 301:# ======= START RUNG 3 =======
 302:LabelRung3:
 303:
 304:set bit '$rung_top'
 306:# start series [
 307:# ELEM_UART_RECV_AVAIL
 308:if '$rung_top' {
 309:    '$rung_top' = is uart receive data available ?
 310:}
 312:# start parallel [
 313:let bit '$parThis_0' := '$rung_top'
 314:# ELEM_UART_RECV
 315:if '$parThis_0' {
 316:    '$parThis_0' = is uart receive data available ?
 317:    if '$parThis_0' {
 318:        let var 'char' := 0
 319:        uart recv into 'char[+0]'
 320:    }
 321:}
 323:let bit '$parThis_0' := '$rung_top'
 324:# ELEM_UART_SEND
 325:if '$parThis_0' {
 326:    uart send from 'char[+0]'
 327:}
 328:'$parThis_0' = is uart busy to send ?
 330:let bit '$parThis_0' := '$rung_top'
 331:# ELEM_FORMATTED_STRING
 332:if '$parThis_0' {
 333:    if not '$once_2_FMTD_STR_' {
 334:        set bit '$once_2_FMTD_STR_'
 335:        let var '$fmtd_4_seq' := 0
 336:        set bit '$fmtd_7_doSend'
 337:    }
 338:} else {
 339:    clear bit '$once_2_FMTD_STR_'
 340:}
 341:let var '$seqScratch' := '$fmtd_4_seq'
 342:if '$fmtd_4_seq' < '23' {
 343:} else {
 344:    let var '$seqScratch' := -1
 345:}
 346:if '$fmtd_7_doSend' {
 347:    clear bit '$scratch'
 348:    '$scratch' = is uart ready to send ?
 349:    if not '$scratch' {
 350:        let var '$seqScratch' := -1
 351:    }
 352:}
 353:let var '$scratch' := 0
 354:if '$scratch' == '$seqScratch' {
 355:    let var '$charToUart' := 13
 356:}
 357:let var '$scratch' := 1
 358:if '$scratch' == '$seqScratch' {
 359:    let var '$charToUart' := 10
 360:}
 361:let var '$scratch' := 2
 362:if '$scratch' == '$seqScratch' {
 363:    let var '$charToUart' := 80
 364:}
 365:let var '$scratch' := 3
 366:if '$scratch' == '$seqScratch' {
 367:    let var '$charToUart' := 87
 368:}
 369:let var '$scratch' := 4
 370:if '$scratch' == '$seqScratch' {
 371:    let var '$charToUart' := 77
 372:}
 373:let var '$scratch' := 5
 374:if '$scratch' == '$seqScratch' {
 375:    let var '$charToUart' := 32
 376:}
 377:let var '$scratch' := 6
 378:if '$scratch' == '$seqScratch' {
 379:    let var '$charToUart' := 68
 380:}
 381:let var '$scratch' := 7
 382:if '$scratch' == '$seqScratch' {
 383:    let var '$charToUart' := 85
 384:}
 385:let var '$scratch' := 8
 386:if '$scratch' == '$seqScratch' {
 387:    let var '$charToUart' := 84
 388:}
 389:let var '$scratch' := 9
 390:if '$scratch' == '$seqScratch' {
 391:    let var '$charToUart' := 89
 392:}
 393:let var '$scratch' := 10
 394:if '$scratch' == '$seqScratch' {
 395:    let var '$charToUart' := 32
 396:}
 397:let var '$scratch' := 11
 398:if '$scratch' == '$seqScratch' {
 399:    let var '$charToUart' := 67
 400:}
 401:let var '$scratch' := 12
 402:if '$scratch' == '$seqScratch' {
 403:    let var '$charToUart' := 89
 404:}
 405:let var '$scratch' := 13
 406:if '$scratch' == '$seqScratch' {
 407:    let var '$charToUart' := 67
 408:}
 409:let var '$scratch' := 14
 410:if '$scratch' == '$seqScratch' {
 411:    let var '$charToUart' := 76
 412:}
 413:let var '$scratch' := 15
 414:if '$scratch' == '$seqScratch' {
 415:    let var '$charToUart' := 69
 416:}
 417:let var '$scratch' := 16
 418:if '$scratch' == '$seqScratch' {
 419:    let var '$charToUart' := 58
 420:}
 421:let var '$scratch' := 17
 422:if '$scratch' == '$seqScratch' {
 423:    let var '$charToUart' := 32
 424:}
 425:let var '$scratch' := 18
 426:clear bit '$scratch'
 427:if '$scratch' == '$seqScratch' {
 428:    set bit '$scratch'
 429:}
 430:if '$scratch' {
 431:    let var '$fmtd_5_convertState' := 'duty'
 432:    set bit '$fmtd_6_isLeadingZero'
 433:    let var '$scratch' := 100
 434:    let var '$charToUart' := '$fmtd_5_convertState' / '$scratch'
 435:    let var '$scratch' := '$scratch' * '$charToUart'
 436:    let var '$fmtd_5_convertState' := '$fmtd_5_convertState' - '$scratch'
 437:    let var '$scratch' := 48
 438:    let var '$charToUart' := '$charToUart' + '$scratch'
 439:    if '$scratch' == '$charToUart' {
 440:        if '$fmtd_6_isLeadingZero' {
 441:            let var '$charToUart' := 32
 442:        }
 443:    } else {
 444:        clear bit '$fmtd_6_isLeadingZero'
 445:    }
 446:}
 447:let var '$scratch' := 19
 448:clear bit '$scratch'
 449:if '$scratch' == '$seqScratch' {
 450:    set bit '$scratch'
 451:}
 452:if '$scratch' {
 453:    let var '$scratch' := 10
 454:    let var '$charToUart' := '$fmtd_5_convertState' / '$scratch'
 455:    let var '$scratch' := '$scratch' * '$charToUart'
 456:    let var '$fmtd_5_convertState' := '$fmtd_5_convertState' - '$scratch'
 457:    let var '$scratch' := 48
 458:    let var '$charToUart' := '$charToUart' + '$scratch'
 459:    if '$scratch' == '$charToUart' {
 460:        if '$fmtd_6_isLeadingZero' {
 461:            let var '$charToUart' := 32
 462:        }
 463:    } else {
 464:        clear bit '$fmtd_6_isLeadingZero'
 465:    }
 466:}
 467:let var '$scratch' := 20
 468:clear bit '$scratch'
 469:if '$scratch' == '$seqScratch' {
 470:    set bit '$scratch'
 471:}
 472:if '$scratch' {
 473:    let var '$scratch' := 1
 474:    let var '$charToUart' := '$fmtd_5_convertState' / '$scratch'
 475:    let var '$scratch' := '$scratch' * '$charToUart'
 476:    let var '$fmtd_5_convertState' := '$fmtd_5_convertState' - '$scratch'
 477:    let var '$scratch' := 48
 478:    let var '$charToUart' := '$charToUart' + '$scratch'
 479:}
 480:let var '$scratch' := 21
 481:if '$scratch' == '$seqScratch' {
 482:    let var '$charToUart' := 13
 483:}
 484:let var '$scratch' := 22
 485:if '$scratch' == '$seqScratch' {
 486:    let var '$charToUart' := 10
 487:}
 488:if '$seqScratch' < '0' {
 489:} else {
 490:    if '$fmtd_7_doSend' {
 491:        uart send from '$charToUart[+0]'
 492:        increment '$fmtd_4_seq'
 493:    }
 494:}
 495:clear bit '$parThis_0'
 496:if '$fmtd_4_seq' < '23' {
 497:    if '$fmtd_7_doSend' {
 498:        set bit '$parThis_0'
 499:    }
 500:} else {
 501:    clear bit '$fmtd_7_doSend'
 502:}
 504:let bit '$parThis_0' := '$rung_top'
 505:# start series [
 506:# ELEM_EQU
 507:if '$parThis_0' {
 508:    if 'char' != ''P'' {
 509:        clear bit '$parThis_0'
 510:    }
 511:}
 513:# ELEM_LES
 514:if '$parThis_0' {
 515:    if 'duty' >= '100' {
 516:        clear bit '$parThis_0'
 517:    }
 518:}
 520:# ELEM_ADD
 521:if '$parThis_0' {
 522:    let var '$scratch2' := 10
 523:    let var 'duty' := 'duty' + '$scratch2'; copy overflow flag to '$overlap'
 524:}
 526:# ] finish series
 527:let bit '$parThis_0' := '$rung_top'
 528:# start series [
 529:# ELEM_EQU
 530:if '$parThis_0' {
 531:    if 'char' != ''M'' {
 532:        clear bit '$parThis_0'
 533:    }
 534:}
 536:# ELEM_GRT
 537:if '$parThis_0' {
 538:    if 'duty' <= '0' {
 539:        clear bit '$parThis_0'
 540:    }
 541:}
 543:# ELEM_SUB
 544:if '$parThis_0' {
 545:    let var '$scratch2' := 10
 546:    let var 'duty' := 'duty' - '$scratch2'; copy overflow flag to '$overlap'
 547:}
 549:# ] finish series
 550:# ] finish parallel
 551:# ] finish series
 552:# 
 553:# ======= START RUNG 4 =======
 554:LabelRung4:
 555:
 556:set bit '$rung_top'
 558:# start series [
 559:# ELEM_SET_PWM
 560:if '$rung_top' {
 561:    set pwm 'duty' % 5000 Hz out 'PWMoutpin'
 562:    set bit '$PWMoutpin'
 563:}
 565:# ] finish series
 566:LabelRung5:
 567:
 568:# Latest INT_OP here
