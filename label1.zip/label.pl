   5:# 
   6:# ======= START RUNG 1 =======
   7:LabelRung1:
   8:
   9:set bit '$rung_top'
  11:# start series [
  12:# ELEM_GOTO 4
  13:if '$rung_top' {
  14:    GOTO LabelRung4 # 4 0
  15:}
  17:# ] finish series
  18:# 
  19:# ======= START RUNG 2 =======
  20:LabelRung2:
  21:
  22:set bit '$rung_top'
  24:# start series [
  25:# ELEM_DELAY
  26:if '$rung_top' {
  27:    DELAY 10000 us;
  28:}
  30:# ELEM_COIL
  31:let bit 'Y0' := '$rung_top'
  33:# ] finish series
  34:# 
  35:# ======= START RUNG 3 =======
  36:LabelRung3:
  37:
  38:set bit '$rung_top'
  40:# start series [
  41:# ELEM_DELAY
  42:if '$rung_top' {
  43:    DELAY 10000 us;
  44:}
  46:# ELEM_COIL
  47:let bit 'Y1' := '$rung_top'
  49:# ] finish series
  50:# 
  51:# ======= START RUNG 4 =======
  52:LabelRung4:
  53:
  54:set bit '$rung_top'
  56:# start series [
  57:# ELEM_COIL
  58:let bit 'Y2' := '$rung_top'
  60:# ] finish series
  61:LabelRung5:
  62:
  63:# Latest INT_OP here
