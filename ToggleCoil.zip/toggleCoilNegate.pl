   5:# 
   6:# ======= START RUNG 1 =======
   7:LabelRung1:
   8:
   9:set bit '$rung_top'
  11:# start series [
  12:# ELEM_CONTACTS
  13:if 'XC2' {
  14:    clear bit '$rung_top'
  15:}
  17:# ELEM_COIL
  18:if '$rung_top' {
  19:    if not '$once_0_TTRIGGER_YB0' {
  20:        set bit '$once_0_TTRIGGER_YB0'
  21:        if 'YB0' {
  22:            clear bit 'YB0'
  23:        } else {
  24:            set bit 'YB0'
  25:        }
  26:    }
  27:} else {
  28:    clear bit '$once_0_TTRIGGER_YB0'
  29:}
  31:# ] finish series
  32:# 
  33:# ======= START RUNG 2 =======
  34:LabelRung2:
  35:
  36:set bit '$rung_top'
  38:# start series [
  39:# ELEM_OPEN
  40:clear bit '$rung_top'
  42:# ELEM_COIL
  43:let bit 'YB1' := '$rung_top'
  45:# ] finish series
  46:# 
  47:# ======= START RUNG 3 =======
  48:LabelRung3:
  49:
  50:set bit '$rung_top'
  52:# start series [
  53:# ELEM_OPEN
  54:clear bit '$rung_top'
  56:# ELEM_COIL
  57:let bit 'YB2' := '$rung_top'
  59:# ] finish series
  60:# 
  61:# ======= START RUNG 4 =======
  62:LabelRung4:
  63:
  64:set bit '$rung_top'
  66:# start series [
  67:# ELEM_OPEN
  68:clear bit '$rung_top'
  70:# ELEM_COIL
  71:let bit 'YB3' := '$rung_top'
  73:# ] finish series
  74:LabelRung5:
  75:
  76:# Latest INT_OP here
