   2:# 
   3:# ======= START RUNG 1 =======
   4:LabelRung1:
   5:
   6:set bit '$rung_top'
   8:# start series [
   9:# ELEM_UART_RECV_AVAIL
  10:if '$rung_top' {
  11:    '$rung_top' = is uart receive data available ?
  12:}
  14:# start parallel [
  15:clear bit '$parOut_0'
  16:let bit '$parThis_0' := '$rung_top'
  17:# ELEM_UART_RECV
  18:if '$parThis_0' {
  19:    '$parThis_0' = is uart receive data available ?
  20:    if '$parThis_0' {
  21:        let var 'char' := 0
  22:        uart recv into 'char[+0]'
  23:    }
  24:}
  26:if '$parThis_0' {
  27:    set bit '$parOut_0'
  28:}
  29:let bit '$parThis_0' := '$rung_top'
  30:# ELEM_UART_SEND
  31:if '$parThis_0' {
  32:    uart send from 'char[+0]'
  33:}
  34:'$parThis_0' = is uart busy to send ?
  36:if '$parThis_0' {
  37:    set bit '$parOut_0'
  38:}
  39:let bit '$rung_top' := '$parOut_0'
  40:# ] finish parallel
  41:# ] finish series
  42:LabelRung2:
  43:
  44:# Latest INT_OP here
