   3:# 
   4:# ======= START RUNG 1 =======
   5:LabelRung1:
   6:
   7:set bit '$rung_top'
   9:# start series [
  10:# ELEM_MOVE
  11:if '$rung_top' {
  12:    let var 'var' := 55
  13:}
  15:# ] finish series
  16:# 
  17:# ======= START RUNG 2 =======
  18:LabelRung2:
  19:
  20:set bit '$rung_top'
  22:# start series [
  23:# ELEM_UART_SENDn
  24:if '$rung_top' {
  25:    if '$rung_top' {
  26:        if '$once_0_SENDn_var' < '1' {
  27:            let var '$once_0_SENDn_var' := 2
  28:            let var '$once_1_SENDv_var' := 'var'
  29:        }
  30:    }
  31:}
  32:if '$once_0_SENDn_var' < '1' {
  33:} else {
  34:    '$rung_top' = is uart ready to send ?
  35:    if '$rung_top' {
  36:        decrement '$once_0_SENDn_var'
  37:        uart send from '$once_1_SENDv_var[$rung_top+0]'
  38:    }
  39:}
  40:if '$once_0_SENDn_var' < '1' {
  41:    clear bit '$rung_top'
  42:} else {
  43:    set bit '$rung_top'
  44:}
  46:# ] finish series
  47:LabelRung3:
  48:
  49:# Latest INT_OP here
