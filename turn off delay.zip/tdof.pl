   0:# INIT VARS
   1:if not '$once_0_INIT_VARS' {
   2:    set bit '$once_0_INIT_VARS'
   3:    let var 'Tnew' := 1000
   4:}
  10:# 
  11:# ======= START RUNG 1 =======
  12:LabelRung1:
  13:
  14:set bit '$rung_top'
  16:# start series [
  17:# ELEM_CONTACTS
  18:if not 'X0' {
  19:    clear bit '$rung_top'
  20:}
  22:# ELEM_ONE_SHOT_RISING
  23:if '$rung_top' {
  24:    if '$once_1_ONE_SHOT_RISING_' {
  25:        clear bit '$rung_top'
  26:    } else {
  27:        set bit '$once_1_ONE_SHOT_RISING_'
  28:    }
  29:} else {
  30:    clear bit '$once_1_ONE_SHOT_RISING_'
  31:}
  33:# ELEM_TOF
  34:if not '$rung_top' {
  35:    if 'Tnew' < '1000' {
  36:        increment 'Tnew'
  37:        set bit '$rung_top'
  38:    }
  39:} else {
  40:    let var 'Tnew' := 0
  41:}
  43:# ELEM_COIL
  44:let bit 'Y0' := '$rung_top'
  46:# ] finish series
  47:# 
  48:# ======= START RUNG 2 =======
  49:LabelRung2:
  50:
  51:set bit '$rung_top'
  53:# start series [
  54:# ELEM_OPEN
  55:clear bit '$rung_top'
  57:# ELEM_COIL
  58:let bit 'Y1' := '$rung_top'
  60:# ] finish series
  61:# 
  62:# ======= START RUNG 3 =======
  63:LabelRung3:
  64:
  65:set bit '$rung_top'
  67:# start series [
  68:# ELEM_OPEN
  69:clear bit '$rung_top'
  71:# ELEM_COIL
  72:let bit 'Y2' := '$rung_top'
  74:# ] finish series
  75:# 
  76:# ======= START RUNG 4 =======
  77:LabelRung4:
  78:
  79:set bit '$rung_top'
  81:# start series [
  82:# ELEM_OPEN
  83:clear bit '$rung_top'
  85:# ELEM_COIL
  86:let bit 'Y3' := '$rung_top'
  88:# ] finish series
  89:LabelRung5:
  90:
  91:# Latest INT_OP here
