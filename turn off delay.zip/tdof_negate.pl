   0:# INIT VARS
   1:if not '$once_0_INIT_VARS' {
   2:    set bit '$once_0_INIT_VARS'
   3:    let var 'Tnew' := 1000
   4:}
  10:# 
  11:# ======= START RUNG 1 =======
  12:LabelRung1:
  13:
  14:set bit '$rung_top'
  16:# start series [
  17:# ELEM_CONTACTS
  18:if 'X0' {
  19:    clear bit '$rung_top'
  20:}
  22:# ELEM_TOF
  23:if not '$rung_top' {
  24:    if 'Tnew' < '1000' {
  25:        increment 'Tnew'
  26:        set bit '$rung_top'
  27:    }
  28:} else {
  29:    let var 'Tnew' := 0
  30:}
  32:# ELEM_COIL
  33:let bit 'Y0' := '$rung_top'
  35:# ] finish series
  36:# 
  37:# ======= START RUNG 2 =======
  38:LabelRung2:
  39:
  40:set bit '$rung_top'
  42:# start series [
  43:# ELEM_OPEN
  44:clear bit '$rung_top'
  46:# ELEM_COIL
  47:let bit 'Y1' := '$rung_top'
  49:# ] finish series
  50:# 
  51:# ======= START RUNG 3 =======
  52:LabelRung3:
  53:
  54:set bit '$rung_top'
  56:# start series [
  57:# ELEM_OPEN
  58:clear bit '$rung_top'
  60:# ELEM_COIL
  61:let bit 'Y2' := '$rung_top'
  63:# ] finish series
  64:# 
  65:# ======= START RUNG 4 =======
  66:LabelRung4:
  67:
  68:set bit '$rung_top'
  70:# start series [
  71:# ELEM_OPEN
  72:clear bit '$rung_top'
  74:# ELEM_COIL
  75:let bit 'Y3' := '$rung_top'
  77:# ] finish series
  78:LabelRung5:
  79:
  80:# Latest INT_OP here
