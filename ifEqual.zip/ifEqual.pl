   5:# 
   6:# ======= START RUNG 1 =======
   7:LabelRung1:
   8:
   9:set bit '$rung_top'
  11:# start series [
  12:# ELEM_UART_RECV_AVAIL
  13:if '$rung_top' {
  14:    '$rung_top' = is uart receive data available ?
  15:}
  17:# start parallel [
  18:clear bit '$parOut_0'
  19:let bit '$parThis_0' := '$rung_top'
  20:# ELEM_UART_RECV
  21:if '$parThis_0' {
  22:    '$parThis_0' = is uart receive data available ?
  23:    if '$parThis_0' {
  24:        let var 'char' := 0
  25:        uart recv into 'char[+0]'
  26:    }
  27:}
  29:if '$parThis_0' {
  30:    set bit '$parOut_0'
  31:}
  32:let bit '$parThis_0' := '$rung_top'
  33:# ELEM_UART_SEND
  34:if '$parThis_0' {
  35:    uart send from 'char[+0]'
  36:}
  37:'$parThis_0' = is uart busy to send ?
  39:if '$parThis_0' {
  40:    set bit '$parOut_0'
  41:}
  42:let bit '$rung_top' := '$parOut_0'
  43:# ] finish parallel
  44:# ] finish series
  45:# 
  46:# ======= START RUNG 2 =======
  47:LabelRung2:
  48:
  49:set bit '$rung_top'
  51:# start series [
  52:# ELEM_EQU
  53:if '$rung_top' {
  54:    if 'char' != ''0'' {
  55:        clear bit '$rung_top'
  56:    }
  57:}
  59:# ELEM_COIL
  60:if '$rung_top' {
  61:    clear bit 'RSTATE'
  62:}
  64:# ] finish series
  65:# 
  66:# ======= START RUNG 3 =======
  67:LabelRung3:
  68:
  69:set bit '$rung_top'
  71:# start series [
  72:# ELEM_EQU
  73:if '$rung_top' {
  74:    if 'char' != ''1'' {
  75:        clear bit '$rung_top'
  76:    }
  77:}
  79:# ELEM_COIL
  80:if '$rung_top' {
  81:    set bit 'RSTATE'
  82:}
  84:# ] finish series
  85:# 
  86:# ======= START RUNG 4 =======
  87:LabelRung4:
  88:
  89:set bit '$rung_top'
  91:# start series [
  92:# ELEM_CONTACTS
  93:if not 'RSTATE' {
  94:    clear bit '$rung_top'
  95:}
  97:# ELEM_COIL
  98:let bit 'Y0' := '$rung_top'
 100:# ] finish series
 101:LabelRung5:
 102:
 103:# Latest INT_OP here
