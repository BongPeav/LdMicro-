   0:# INIT TABLES
   1:INIT TABLE signed 1 byte tab1[5] := {65, 66, 67, 68, 69}
   2:# INIT VARS
   3:if not '$once_0_INIT_VARS' {
   4:    set bit '$once_0_INIT_VARS'
   5:    let var 'C0' := 0
   6:}
  12:# 
  13:# ======= START RUNG 1 =======
  14:LabelRung1:
  15:
  16:set bit '$rung_top'
  18:# start series [
  19:# ELEM_LOOK_UP_TABLE tab1
  20:if '$rung_top' {
  21:    let var 'char' := 'tab1[C0]'
  22:}
  24:# ] finish series
  25:# 
  26:# ======= START RUNG 2 =======
  27:LabelRung2:
  28:
  29:set bit '$rung_top'
  31:# start series [
  32:# ELEM_TCY T0 500000
  33:if '$rung_top' {
  34:    if 'T0' < '50' {
  35:        increment 'T0'
  36:    } else {
  37:        let var 'T0' := 0
  38:        if not '$once_1_TCY_T0' {
  39:            set bit '$once_1_TCY_T0'
  40:        } else {
  41:            clear bit '$once_1_TCY_T0'
  42:        }
  43:    }
  44:    if not '$once_1_TCY_T0' {
  45:        clear bit '$rung_top'
  46:    }
  47:} else {
  48:    let var 'T0' := 0
  49:}
  51:# ELEM_COIL
  52:let bit 'Rstate' := '$rung_top'
  54:# ] finish series
  55:# 
  56:# ======= START RUNG 3 =======
  57:LabelRung3:
  58:
  59:set bit '$rung_top'
  61:# start series [
  62:# ELEM_CONTACTS
  63:if not 'Rstate' {
  64:    clear bit '$rung_top'
  65:}
  67:# ELEM_ONE_SHOT_RISING
  68:if '$rung_top' {
  69:    if '$once_2_ONE_SHOT_RISING_' {
  70:        clear bit '$rung_top'
  71:    } else {
  72:        set bit '$once_2_ONE_SHOT_RISING_'
  73:    }
  74:} else {
  75:    clear bit '$once_2_ONE_SHOT_RISING_'
  76:}
  78:# ELEM_CTC
  79:if '$rung_top' {
  80:    clear bit '$rung_top'
  81:    if not '$once_3_CTC_C0' {
  82:        set bit '$once_3_CTC_C0'
  83:        increment 'C0'
  84:        if 'C0' > '4' {
  85:            let var 'C0' := 0
  86:            set bit '$rung_top'
  87:        }
  88:    }
  89:} else {
  90:    clear bit '$once_3_CTC_C0'
  91:}
  93:# ] finish series
  94:# 
  95:# ======= START RUNG 4 =======
  96:LabelRung4:
  97:
  98:set bit '$rung_top'
 100:# start series [
 101:# ELEM_CONTACTS
 102:if not 'Rstate' {
 103:    clear bit '$rung_top'
 104:}
 106:# ELEM_ONE_SHOT_RISING
 107:if '$rung_top' {
 108:    if '$once_4_ONE_SHOT_RISING_' {
 109:        clear bit '$rung_top'
 110:    } else {
 111:        set bit '$once_4_ONE_SHOT_RISING_'
 112:    }
 113:} else {
 114:    clear bit '$once_4_ONE_SHOT_RISING_'
 115:}
 117:# ELEM_UART_SEND
 118:if '$rung_top' {
 119:    uart send from 'char[+0]'
 120:}
 121:'$rung_top' = is uart busy to send ?
 123:# ] finish series
 124:LabelRung5:
 125:
 126:# Latest INT_OP here
