   6:# 
   7:# ======= START RUNG 1 =======
   8:LabelRung1:
   9:
  10:set bit '$rung_top'
  12:# start series [
  13:# ELEM_UART_RECV_AVAIL
  14:if '$rung_top' {
  15:    '$rung_top' = is uart receive data available ?
  16:}
  18:# start parallel [
  19:clear bit '$parOut_0'
  20:let bit '$parThis_0' := '$rung_top'
  21:# ELEM_UART_RECV
  22:if '$parThis_0' {
  23:    '$parThis_0' = is uart receive data available ?
  24:    if '$parThis_0' {
  25:        let var 'char' := 0
  26:        uart recv into 'char[+0]'
  27:    }
  28:}
  30:if '$parThis_0' {
  31:    set bit '$parOut_0'
  32:}
  33:let bit '$parThis_0' := '$rung_top'
  34:# ELEM_UART_SEND
  35:if '$parThis_0' {
  36:    uart send from 'char[+0]'
  37:}
  38:'$parThis_0' = is uart busy to send ?
  40:if '$parThis_0' {
  41:    set bit '$parOut_0'
  42:}
  43:let bit '$rung_top' := '$parOut_0'
  44:# ] finish parallel
  45:# ] finish series
  46:# 
  47:# ======= START RUNG 2 =======
  48:LabelRung2:
  49:
  50:set bit '$rung_top'
  52:# start series [
  53:# ELEM_NEQ
  54:if '$rung_top' {
  55:    if 'char' == ''A'' {
  56:        clear bit '$rung_top'
  57:    }
  58:}
  60:# ELEM_COIL
  61:let bit 'Y0' := '$rung_top'
  63:# ] finish series
  64:# 
  65:# ======= START RUNG 3 =======
  66:LabelRung3:
  67:
  68:set bit '$rung_top'
  70:# start series [
  71:# ELEM_OPEN
  72:clear bit '$rung_top'
  74:# ELEM_COIL
  75:let bit 'Y1' := '$rung_top'
  77:# ] finish series
  78:# 
  79:# ======= START RUNG 4 =======
  80:LabelRung4:
  81:
  82:set bit '$rung_top'
  84:# start series [
  85:# ELEM_OPEN
  86:clear bit '$rung_top'
  88:# ELEM_COIL
  89:let bit 'Y2' := '$rung_top'
  91:# ] finish series
  92:# 
  93:# ======= START RUNG 5 =======
  94:LabelRung5:
  95:
  96:set bit '$rung_top'
  98:# start series [
  99:# ELEM_OPEN
 100:clear bit '$rung_top'
 102:# ELEM_COIL
 103:let bit 'Y3' := '$rung_top'
 105:# ] finish series
 106:LabelRung6:
 107:
 108:# Latest INT_OP here
