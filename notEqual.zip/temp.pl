   2:# 
   3:# ======= START RUNG 1 =======
   4:LabelRung1:
   5:
   6:set bit '$rung_top'
   8:# start series [
   9:# ELEM_CONTACTS
  10:if not 'Xon_off' {
  11:    clear bit '$rung_top'
  12:}
  14:# ELEM_COIL
  15:if '$rung_top' {
  16:    if not '$once_0_TTRIGGER_Y0' {
  17:        set bit '$once_0_TTRIGGER_Y0'
  18:        if 'Y0' {
  19:            clear bit 'Y0'
  20:        } else {
  21:            set bit 'Y0'
  22:        }
  23:    }
  24:} else {
  25:    clear bit '$once_0_TTRIGGER_Y0'
  26:}
  28:# ] finish series
  29:LabelRung2:
  30:
  31:# Latest INT_OP here
