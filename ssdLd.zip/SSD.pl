   0:# INIT TABLES
   1:INIT TABLE signed 1 byte char7seg[129] := {63, 6, 91, 79, 102, 109, 125, 7, 127, 111, 119, 124, 57, 94, 121, 113, 191, 134, 219, 207, 230, 237, 253, 135, 255, 239, 247, 252, 185, 222, 249, 241, 0, 176, 34, 78, 109, 210, 218, 32, 57, 15, 114, 112, 12, 64, 128, 82, 63, 6, 91, 79, 102, 109, 125, 7, 127, 111, 9, 13, 97, 65, 67, 211, 159, 119, 124, 57, 94, 121, 113, 61, 116, 48, 30, 117, 56, 85, 84, 92, 115, 103, 51, 109, 120, 62, 28, 106, 118, 110, 91, 57, 100, 15, 35, 8, 32, 95, 124, 88, 94, 123, 113, 111, 116, 16, 14, 117, 24, 85, 84, 92, 115, 103, 80, 109, 120, 62, 28, 106, 118, 110, 91, 57, 48, 15, 1, 0, 99}
   2:# INIT VARS
   3:if not '$once_0_INIT_VARS' {
   4:    set bit '$once_0_INIT_VARS'
   5:    let var 'C0' := 0
   6:    let var 'T0' := 300
   7:}
  12:# 
  13:# ======= START RUNG 1 =======
  14:LabelRung1:
  15:
  16:set bit '$rung_top'
  18:# start series [
  19:# ELEM_ONE_SHOT_RISING
  20:if '$rung_top' {
  21:    if '$once_1_ONE_SHOT_RISING_' {
  22:        clear bit '$rung_top'
  23:    } else {
  24:        set bit '$once_1_ONE_SHOT_RISING_'
  25:    }
  26:} else {
  27:    clear bit '$once_1_ONE_SHOT_RISING_'
  28:}
  30:# ELEM_MOVE
  31:if '$rung_top' {
  32:    let var '#TRISB' := 0
  33:}
  35:# ] finish series
  36:# 
  37:# ======= START RUNG 2 =======
  38:LabelRung2:
  39:
  40:set bit '$rung_top'
  42:# start series [
  43:# ELEM_CONTACTS
  44:if not 'X0' {
  45:    clear bit '$rung_top'
  46:}
  48:# ELEM_ONE_SHOT_RISING
  49:if '$rung_top' {
  50:    if '$once_2_ONE_SHOT_RISING_' {
  51:        clear bit '$rung_top'
  52:    } else {
  53:        set bit '$once_2_ONE_SHOT_RISING_'
  54:    }
  55:} else {
  56:    clear bit '$once_2_ONE_SHOT_RISING_'
  57:}
  59:# ELEM_CTC
  60:if '$rung_top' {
  61:    clear bit '$rung_top'
  62:    if not '$once_3_CTC_C0' {
  63:        set bit '$once_3_CTC_C0'
  64:        increment 'C0'
  65:        if 'C0' > '15' {
  66:            let var 'C0' := 0
  67:            set bit '$rung_top'
  68:        }
  69:    }
  70:} else {
  71:    clear bit '$once_3_CTC_C0'
  72:}
  74:# ELEM_TOF
  75:if not '$rung_top' {
  76:    if 'T0' < '300' {
  77:        increment 'T0'
  78:        set bit '$rung_top'
  79:    }
  80:} else {
  81:    let var 'T0' := 0
  82:}
  84:# ELEM_COIL
  85:let bit 'Y0' := '$rung_top'
  87:# ] finish series
  88:# 
  89:# ======= START RUNG 3 =======
  90:LabelRung3:
  91:
  92:set bit '$rung_top'
  94:# start series [
  95:# ELEM_7SEG
  96:if '$rung_top' {
  97:    let var '$scratch' := 176
  98:    if 'C0' == '$scratch' {
  99:        let var 'C0' := 128
 100:    } else {
 101:        if 'C0' < '0' {
 102:            let var 'C0' := 32
 103:        } else {
 104:            if 'C0' < '129' {
 105:            } else {
 106:                let var 'C0' := 32
 107:            }
 108:        }
 109:    }
 110:    let var '$scratch' := 'char7seg[C0]'
 111:    let var '#PORTB' := '$scratch'
 112:}
 114:# ] finish series
 115:LabelRung4:
 116:
 117:# Latest INT_OP here
