   0:# INIT TABLES
   1:# INIT VARS
   2:if not '$once_0_INIT_VARS' {
   3:    set bit '$once_0_INIT_VARS'
   4:    let var 'C0' := 0
   5:}
   8:# 
   9:# ======= START RUNG 1 =======
  10:LabelRung1:
  11:
  12:set bit '$rung_top'
  14:# start series [
  15:# ELEM_TCY Tnew 500000
  16:if '$rung_top' {
  17:    if 'Tnew' < '50' {
  18:        increment 'Tnew'
  19:    } else {
  20:        let var 'Tnew' := 0
  21:        if not '$once_1_TCY_Tnew' {
  22:            set bit '$once_1_TCY_Tnew'
  23:        } else {
  24:            clear bit '$once_1_TCY_Tnew'
  25:        }
  26:    }
  27:    if not '$once_1_TCY_Tnew' {
  28:        clear bit '$rung_top'
  29:    }
  30:} else {
  31:    let var 'Tnew' := 0
  32:}
  34:# start parallel [
  35:clear bit '$parOut_0'
  36:let bit '$parThis_0' := '$rung_top'
  37:# ELEM_CTC
  38:if '$parThis_0' {
  39:    clear bit '$parThis_0'
  40:    if not '$once_2_CTC_C0' {
  41:        set bit '$once_2_CTC_C0'
  42:        increment 'C0'
  43:        if 'C0' > '30' {
  44:            let var 'C0' := 0
  45:            set bit '$parThis_0'
  46:        }
  47:    }
  48:} else {
  49:    clear bit '$once_2_CTC_C0'
  50:}
  52:if '$parThis_0' {
  53:    set bit '$parOut_0'
  54:}
  55:let bit '$parThis_0' := '$rung_top'
  56:# ELEM_FORMATTED_STRING
  57:if '$parThis_0' {
  58:    if not '$once_3_FMTD_STR_' {
  59:        set bit '$once_3_FMTD_STR_'
  60:        let var '$fmtd_0_seq' := 0
  61:        set bit '$fmtd_3_doSend'
  62:    }
  63:} else {
  64:    clear bit '$once_3_FMTD_STR_'
  65:}
  66:let var '$seqScratch' := '$fmtd_0_seq'
  67:if '$fmtd_0_seq' < '27' {
  68:} else {
  69:    let var '$seqScratch' := -1
  70:}
  71:if '$fmtd_3_doSend' {
  72:    clear bit '$scratch'
  73:    '$scratch' = is uart ready to send ?
  74:    if not '$scratch' {
  75:        let var '$seqScratch' := -1
  76:    }
  77:}
  78:let var '$scratch' := 0
  79:if '$scratch' == '$seqScratch' {
  80:    let var '$charToUart' := 67
  81:}
  82:let var '$scratch' := 1
  83:if '$scratch' == '$seqScratch' {
  84:    let var '$charToUart' := 111
  85:}
  86:let var '$scratch' := 2
  87:if '$scratch' == '$seqScratch' {
  88:    let var '$charToUart' := 117
  89:}
  90:let var '$scratch' := 3
  91:if '$scratch' == '$seqScratch' {
  92:    let var '$charToUart' := 110
  93:}
  94:let var '$scratch' := 4
  95:if '$scratch' == '$seqScratch' {
  96:    let var '$charToUart' := 116
  97:}
  98:let var '$scratch' := 5
  99:if '$scratch' == '$seqScratch' {
 100:    let var '$charToUart' := 101
 101:}
 102:let var '$scratch' := 6
 103:if '$scratch' == '$seqScratch' {
 104:    let var '$charToUart' := 114
 105:}
 106:let var '$scratch' := 7
 107:if '$scratch' == '$seqScratch' {
 108:    let var '$charToUart' := 32
 109:}
 110:let var '$scratch' := 8
 111:if '$scratch' == '$seqScratch' {
 112:    let var '$charToUart' := 118
 113:}
 114:let var '$scratch' := 9
 115:if '$scratch' == '$seqScratch' {
 116:    let var '$charToUart' := 97
 117:}
 118:let var '$scratch' := 10
 119:if '$scratch' == '$seqScratch' {
 120:    let var '$charToUart' := 108
 121:}
 122:let var '$scratch' := 11
 123:if '$scratch' == '$seqScratch' {
 124:    let var '$charToUart' := 117
 125:}
 126:let var '$scratch' := 12
 127:if '$scratch' == '$seqScratch' {
 128:    let var '$charToUart' := 101
 129:}
 130:let var '$scratch' := 13
 131:if '$scratch' == '$seqScratch' {
 132:    let var '$charToUart' := 32
 133:}
 134:let var '$scratch' := 14
 135:if '$scratch' == '$seqScratch' {
 136:    let var '$charToUart' := 111
 137:}
 138:let var '$scratch' := 15
 139:if '$scratch' == '$seqScratch' {
 140:    let var '$charToUart' := 102
 141:}
 142:let var '$scratch' := 16
 143:if '$scratch' == '$seqScratch' {
 144:    let var '$charToUart' := 32
 145:}
 146:let var '$scratch' := 17
 147:if '$scratch' == '$seqScratch' {
 148:    let var '$charToUart' := 67
 149:}
 150:let var '$scratch' := 18
 151:if '$scratch' == '$seqScratch' {
 152:    let var '$charToUart' := 48
 153:}
 154:let var '$scratch' := 19
 155:if '$scratch' == '$seqScratch' {
 156:    let var '$charToUart' := 32
 157:}
 158:let var '$scratch' := 20
 159:if '$scratch' == '$seqScratch' {
 160:    let var '$charToUart' := 58
 161:}
 162:let var '$scratch' := 21
 163:if '$scratch' == '$seqScratch' {
 164:    let var '$charToUart' := 32
 165:}
 166:let var '$scratch' := 22
 167:clear bit '$scratch'
 168:if '$scratch' == '$seqScratch' {
 169:    set bit '$scratch'
 170:}
 171:if '$scratch' {
 172:    let var '$fmtd_1_convertState' := 'C0'
 173:    set bit '$fmtd_2_isLeadingZero'
 174:    let var '$scratch' := 100
 175:    let var '$charToUart' := '$fmtd_1_convertState' / '$scratch'
 176:    let var '$scratch' := '$scratch' * '$charToUart'
 177:    let var '$fmtd_1_convertState' := '$fmtd_1_convertState' - '$scratch'
 178:    let var '$scratch' := 48
 179:    let var '$charToUart' := '$charToUart' + '$scratch'
 180:    if '$scratch' == '$charToUart' {
 181:        if '$fmtd_2_isLeadingZero' {
 182:            let var '$charToUart' := 32
 183:        }
 184:    } else {
 185:        clear bit '$fmtd_2_isLeadingZero'
 186:    }
 187:}
 188:let var '$scratch' := 23
 189:clear bit '$scratch'
 190:if '$scratch' == '$seqScratch' {
 191:    set bit '$scratch'
 192:}
 193:if '$scratch' {
 194:    let var '$scratch' := 10
 195:    let var '$charToUart' := '$fmtd_1_convertState' / '$scratch'
 196:    let var '$scratch' := '$scratch' * '$charToUart'
 197:    let var '$fmtd_1_convertState' := '$fmtd_1_convertState' - '$scratch'
 198:    let var '$scratch' := 48
 199:    let var '$charToUart' := '$charToUart' + '$scratch'
 200:    if '$scratch' == '$charToUart' {
 201:        if '$fmtd_2_isLeadingZero' {
 202:            let var '$charToUart' := 32
 203:        }
 204:    } else {
 205:        clear bit '$fmtd_2_isLeadingZero'
 206:    }
 207:}
 208:let var '$scratch' := 24
 209:clear bit '$scratch'
 210:if '$scratch' == '$seqScratch' {
 211:    set bit '$scratch'
 212:}
 213:if '$scratch' {
 214:    let var '$scratch' := 1
 215:    let var '$charToUart' := '$fmtd_1_convertState' / '$scratch'
 216:    let var '$scratch' := '$scratch' * '$charToUart'
 217:    let var '$fmtd_1_convertState' := '$fmtd_1_convertState' - '$scratch'
 218:    let var '$scratch' := 48
 219:    let var '$charToUart' := '$charToUart' + '$scratch'
 220:}
 221:let var '$scratch' := 25
 222:if '$scratch' == '$seqScratch' {
 223:    let var '$charToUart' := 13
 224:}
 225:let var '$scratch' := 26
 226:if '$scratch' == '$seqScratch' {
 227:    let var '$charToUart' := 10
 228:}
 229:if '$seqScratch' < '0' {
 230:} else {
 231:    if '$fmtd_3_doSend' {
 232:        uart send from '$charToUart[+0]'
 233:        increment '$fmtd_0_seq'
 234:    }
 235:}
 236:clear bit '$parThis_0'
 237:if '$fmtd_0_seq' < '27' {
 238:    if '$fmtd_3_doSend' {
 239:        set bit '$parThis_0'
 240:    }
 241:} else {
 242:    clear bit '$fmtd_3_doSend'
 243:}
 245:if '$parThis_0' {
 246:    set bit '$parOut_0'
 247:}
 248:let bit '$rung_top' := '$parOut_0'
 249:# ] finish parallel
 250:# ] finish series
 251:LabelRung2:
 252:
 253:# Latest INT_OP here
