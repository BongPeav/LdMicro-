   2:# 
   3:# ======= START RUNG 1 =======
   4:LabelRung1:
   5:
   6:set bit '$rung_top'
   8:# start series [
   9:# ELEM_UART_RECV_AVAIL
  10:if '$rung_top' {
  11:    '$rung_top' = is uart receive data available ?
  12:}
  14:# ELEM_UART_RECV
  15:if '$rung_top' {
  16:    '$rung_top' = is uart receive data available ?
  17:    if '$rung_top' {
  18:        let var 'char' := 0
  19:        uart recv into 'char[+0]'
  20:    }
  21:}
  23:# ELEM_UART_SEND
  24:if '$rung_top' {
  25:    uart send from 'char[+0]'
  26:}
  27:'$rung_top' = is uart busy to send ?
  29:# ] finish series
  30:LabelRung2:
  31:
  32:# Latest INT_OP here
