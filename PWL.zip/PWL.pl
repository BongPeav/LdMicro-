   0:# INIT TABLES
   6:# 
   7:# ======= START RUNG 1 =======
   8:LabelRung1:
   9:
  10:set bit '$rung_top'
  12:# start series [
  13:# ELEM_PIECEWISE_LINEAR
  14:if '$rung_top' {
  15:    # PWL 1
  16:    clear bit '$scratch'
  17:    if 'ADC0' < '1024' {
  18:        set bit '$scratch'
  19:    }
  20:    if '$scratch' {
  21:        let var 'var' := 'ADC0' - '0'
  22:        let var 'var' := 'var' * '5'
  23:        let var 'var' := 'var' / '1023'
  24:        let var 'var' := 'var' + '0'
  25:    }
  26:}
  28:# ] finish series
  29:# 
  30:# ======= START RUNG 2 =======
  31:LabelRung2:
  32:
  33:set bit '$rung_top'
  35:# start series [
  36:# ELEM_TCY T0 300000
  37:if '$rung_top' {
  38:    if 'T0' < '30' {
  39:        increment 'T0'
  40:    } else {
  41:        let var 'T0' := 0
  42:        if not '$once_0_TCY_T0' {
  43:            set bit '$once_0_TCY_T0'
  44:        } else {
  45:            clear bit '$once_0_TCY_T0'
  46:        }
  47:    }
  48:    if not '$once_0_TCY_T0' {
  49:        clear bit '$rung_top'
  50:    }
  51:} else {
  52:    let var 'T0' := 0
  53:}
  55:# ELEM_COIL
  56:let bit 'Rstate' := '$rung_top'
  58:# ] finish series
  59:# 
  60:# ======= START RUNG 3 =======
  61:LabelRung3:
  62:
  63:set bit '$rung_top'
  65:# start series [
  66:# ELEM_CONTACTS
  67:if not 'Rstate' {
  68:    clear bit '$rung_top'
  69:}
  71:# ELEM_READ_ADC
  72:if '$rung_top' {
  73:    read adc 'ADC0', refs is '0'
  74:}
  76:# ] finish series
  77:# 
  78:# ======= START RUNG 4 =======
  79:LabelRung4:
  80:
  81:set bit '$rung_top'
  83:# start series [
  84:# ELEM_CONTACTS
  85:if not 'Rstate' {
  86:    clear bit '$rung_top'
  87:}
  89:# ELEM_FORMATTED_STRING
  90:if '$rung_top' {
  91:    if not '$once_1_FMTD_STR_' {
  92:        set bit '$once_1_FMTD_STR_'
  93:        let var '$fmtd_0_seq' := 0
  94:        set bit '$fmtd_3_doSend'
  95:    }
  96:} else {
  97:    clear bit '$once_1_FMTD_STR_'
  98:}
  99:let var '$seqScratch' := '$fmtd_0_seq'
 100:if '$fmtd_0_seq' < '20' {
 101:} else {
 102:    let var '$seqScratch' := -1
 103:}
 104:if '$fmtd_3_doSend' {
 105:    clear bit '$scratch'
 106:    '$scratch' = is uart ready to send ?
 107:    if not '$scratch' {
 108:        let var '$seqScratch' := -1
 109:    }
 110:}
 111:let var '$scratch' := 0
 112:if '$scratch' == '$seqScratch' {
 113:    let var '$charToUart' := 86
 114:}
 115:let var '$scratch' := 1
 116:if '$scratch' == '$seqScratch' {
 117:    let var '$charToUart' := 111
 118:}
 119:let var '$scratch' := 2
 120:if '$scratch' == '$seqScratch' {
 121:    let var '$charToUart' := 108
 122:}
 123:let var '$scratch' := 3
 124:if '$scratch' == '$seqScratch' {
 125:    let var '$charToUart' := 116
 126:}
 127:let var '$scratch' := 4
 128:if '$scratch' == '$seqScratch' {
 129:    let var '$charToUart' := 97
 130:}
 131:let var '$scratch' := 5
 132:if '$scratch' == '$seqScratch' {
 133:    let var '$charToUart' := 103
 134:}
 135:let var '$scratch' := 6
 136:if '$scratch' == '$seqScratch' {
 137:    let var '$charToUart' := 101
 138:}
 139:let var '$scratch' := 7
 140:if '$scratch' == '$seqScratch' {
 141:    let var '$charToUart' := 32
 142:}
 143:let var '$scratch' := 8
 144:if '$scratch' == '$seqScratch' {
 145:    let var '$charToUart' := 118
 146:}
 147:let var '$scratch' := 9
 148:if '$scratch' == '$seqScratch' {
 149:    let var '$charToUart' := 97
 150:}
 151:let var '$scratch' := 10
 152:if '$scratch' == '$seqScratch' {
 153:    let var '$charToUart' := 108
 154:}
 155:let var '$scratch' := 11
 156:if '$scratch' == '$seqScratch' {
 157:    let var '$charToUart' := 117
 158:}
 159:let var '$scratch' := 12
 160:if '$scratch' == '$seqScratch' {
 161:    let var '$charToUart' := 101
 162:}
 163:let var '$scratch' := 13
 164:if '$scratch' == '$seqScratch' {
 165:    let var '$charToUart' := 58
 166:}
 167:let var '$scratch' := 14
 168:if '$scratch' == '$seqScratch' {
 169:    let var '$charToUart' := 32
 170:}
 171:let var '$scratch' := 15
 172:clear bit '$scratch'
 173:if '$scratch' == '$seqScratch' {
 174:    set bit '$scratch'
 175:}
 176:if '$scratch' {
 177:    let var '$fmtd_1_convertState' := 'var'
 178:    set bit '$fmtd_2_isLeadingZero'
 179:    let var '$scratch' := 100
 180:    let var '$charToUart' := '$fmtd_1_convertState' / '$scratch'
 181:    let var '$scratch' := '$scratch' * '$charToUart'
 182:    let var '$fmtd_1_convertState' := '$fmtd_1_convertState' - '$scratch'
 183:    let var '$scratch' := 48
 184:    let var '$charToUart' := '$charToUart' + '$scratch'
 185:    if '$scratch' == '$charToUart' {
 186:        if '$fmtd_2_isLeadingZero' {
 187:            let var '$charToUart' := 32
 188:        }
 189:    } else {
 190:        clear bit '$fmtd_2_isLeadingZero'
 191:    }
 192:}
 193:let var '$scratch' := 16
 194:clear bit '$scratch'
 195:if '$scratch' == '$seqScratch' {
 196:    set bit '$scratch'
 197:}
 198:if '$scratch' {
 199:    let var '$scratch' := 10
 200:    let var '$charToUart' := '$fmtd_1_convertState' / '$scratch'
 201:    let var '$scratch' := '$scratch' * '$charToUart'
 202:    let var '$fmtd_1_convertState' := '$fmtd_1_convertState' - '$scratch'
 203:    let var '$scratch' := 48
 204:    let var '$charToUart' := '$charToUart' + '$scratch'
 205:    if '$scratch' == '$charToUart' {
 206:        if '$fmtd_2_isLeadingZero' {
 207:            let var '$charToUart' := 32
 208:        }
 209:    } else {
 210:        clear bit '$fmtd_2_isLeadingZero'
 211:    }
 212:}
 213:let var '$scratch' := 17
 214:clear bit '$scratch'
 215:if '$scratch' == '$seqScratch' {
 216:    set bit '$scratch'
 217:}
 218:if '$scratch' {
 219:    let var '$scratch' := 1
 220:    let var '$charToUart' := '$fmtd_1_convertState' / '$scratch'
 221:    let var '$scratch' := '$scratch' * '$charToUart'
 222:    let var '$fmtd_1_convertState' := '$fmtd_1_convertState' - '$scratch'
 223:    let var '$scratch' := 48
 224:    let var '$charToUart' := '$charToUart' + '$scratch'
 225:}
 226:let var '$scratch' := 18
 227:if '$scratch' == '$seqScratch' {
 228:    let var '$charToUart' := 13
 229:}
 230:let var '$scratch' := 19
 231:if '$scratch' == '$seqScratch' {
 232:    let var '$charToUart' := 10
 233:}
 234:if '$seqScratch' < '0' {
 235:} else {
 236:    if '$fmtd_3_doSend' {
 237:        uart send from '$charToUart[+0]'
 238:        increment '$fmtd_0_seq'
 239:    }
 240:}
 241:clear bit '$rung_top'
 242:if '$fmtd_0_seq' < '20' {
 243:    if '$fmtd_3_doSend' {
 244:        set bit '$rung_top'
 245:    }
 246:} else {
 247:    clear bit '$fmtd_3_doSend'
 248:}
 250:# ] finish series
 251:LabelRung5:
 252:
 253:# Latest INT_OP here
