   0:# INIT TABLES
   7:# 
   8:# ======= START RUNG 1 =======
   9:LabelRung1:
  10:
  11:set bit '$rung_top'
  13:# start series [
  14:# ELEM_PIECEWISE_LINEAR
  15:if '$rung_top' {
  16:    # PWL 2
  17:    clear bit '$scratch'
  18:    if 'ADC0' < '1024' {
  19:        set bit '$scratch'
  20:    }
  21:    if '$scratch' {
  22:        let var 'duty_cycle' := 'ADC0' - '512'
  23:        let var 'duty_cycle' := 'duty_cycle' * '50'
  24:        let var 'duty_cycle' := 'duty_cycle' / '511'
  25:        let var 'duty_cycle' := 'duty_cycle' + '50'
  26:    }
  27:    # PWL 1
  28:    clear bit '$scratch'
  29:    if 'ADC0' < '513' {
  30:        set bit '$scratch'
  31:    }
  32:    if '$scratch' {
  33:        let var 'duty_cycle' := 'ADC0' - '0'
  34:        let var 'duty_cycle' := 'duty_cycle' * '50'
  35:        let var 'duty_cycle' := 'duty_cycle' / '512'
  36:        let var 'duty_cycle' := 'duty_cycle' + '0'
  37:    }
  38:}
  40:# ] finish series
  41:# 
  42:# ======= START RUNG 2 =======
  43:LabelRung2:
  44:
  45:set bit '$rung_top'
  47:# start series [
  48:# ELEM_TCY T0 250000
  49:if '$rung_top' {
  50:    if 'T0' < '25' {
  51:        increment 'T0'
  52:    } else {
  53:        let var 'T0' := 0
  54:        if not '$once_0_TCY_T0' {
  55:            set bit '$once_0_TCY_T0'
  56:        } else {
  57:            clear bit '$once_0_TCY_T0'
  58:        }
  59:    }
  60:    if not '$once_0_TCY_T0' {
  61:        clear bit '$rung_top'
  62:    }
  63:} else {
  64:    let var 'T0' := 0
  65:}
  67:# ELEM_COIL
  68:let bit 'Ron' := '$rung_top'
  70:# ] finish series
  71:# 
  72:# ======= START RUNG 3 =======
  73:LabelRung3:
  74:
  75:set bit '$rung_top'
  77:# start series [
  78:# ELEM_CONTACTS
  79:if not 'Ron' {
  80:    clear bit '$rung_top'
  81:}
  83:# ELEM_READ_ADC
  84:if '$rung_top' {
  85:    read adc 'ADC0', refs is '0'
  86:}
  88:# ] finish series
  89:# 
  90:# ======= START RUNG 4 =======
  91:LabelRung4:
  92:
  93:set bit '$rung_top'
  95:# start series [
  96:# ELEM_CONTACTS
  97:if 'Ron' {
  98:    clear bit '$rung_top'
  99:}
 101:# ELEM_FORMATTED_STRING
 102:if '$rung_top' {
 103:    if not '$once_1_FMTD_STR_' {
 104:        set bit '$once_1_FMTD_STR_'
 105:        let var '$fmtd_0_seq' := 0
 106:        set bit '$fmtd_3_doSend'
 107:    }
 108:} else {
 109:    clear bit '$once_1_FMTD_STR_'
 110:}
 111:let var '$seqScratch' := '$fmtd_0_seq'
 112:if '$fmtd_0_seq' < '22' {
 113:} else {
 114:    let var '$seqScratch' := -1
 115:}
 116:if '$fmtd_3_doSend' {
 117:    clear bit '$scratch'
 118:    '$scratch' = is uart ready to send ?
 119:    if not '$scratch' {
 120:        let var '$seqScratch' := -1
 121:    }
 122:}
 123:let var '$scratch' := 0
 124:if '$scratch' == '$seqScratch' {
 125:    let var '$charToUart' := 80
 126:}
 127:let var '$scratch' := 1
 128:if '$scratch' == '$seqScratch' {
 129:    let var '$charToUart' := 87
 130:}
 131:let var '$scratch' := 2
 132:if '$scratch' == '$seqScratch' {
 133:    let var '$charToUart' := 77
 134:}
 135:let var '$scratch' := 3
 136:if '$scratch' == '$seqScratch' {
 137:    let var '$charToUart' := 32
 138:}
 139:let var '$scratch' := 4
 140:if '$scratch' == '$seqScratch' {
 141:    let var '$charToUart' := 68
 142:}
 143:let var '$scratch' := 5
 144:if '$scratch' == '$seqScratch' {
 145:    let var '$charToUart' := 117
 146:}
 147:let var '$scratch' := 6
 148:if '$scratch' == '$seqScratch' {
 149:    let var '$charToUart' := 116
 150:}
 151:let var '$scratch' := 7
 152:if '$scratch' == '$seqScratch' {
 153:    let var '$charToUart' := 121
 154:}
 155:let var '$scratch' := 8
 156:if '$scratch' == '$seqScratch' {
 157:    let var '$charToUart' := 32
 158:}
 159:let var '$scratch' := 9
 160:if '$scratch' == '$seqScratch' {
 161:    let var '$charToUart' := 67
 162:}
 163:let var '$scratch' := 10
 164:if '$scratch' == '$seqScratch' {
 165:    let var '$charToUart' := 121
 166:}
 167:let var '$scratch' := 11
 168:if '$scratch' == '$seqScratch' {
 169:    let var '$charToUart' := 99
 170:}
 171:let var '$scratch' := 12
 172:if '$scratch' == '$seqScratch' {
 173:    let var '$charToUart' := 108
 174:}
 175:let var '$scratch' := 13
 176:if '$scratch' == '$seqScratch' {
 177:    let var '$charToUart' := 101
 178:}
 179:let var '$scratch' := 14
 180:if '$scratch' == '$seqScratch' {
 181:    let var '$charToUart' := 58
 182:}
 183:let var '$scratch' := 15
 184:if '$scratch' == '$seqScratch' {
 185:    let var '$charToUart' := 32
 186:}
 187:let var '$scratch' := 16
 188:clear bit '$scratch'
 189:if '$scratch' == '$seqScratch' {
 190:    set bit '$scratch'
 191:}
 192:if '$scratch' {
 193:    let var '$fmtd_1_convertState' := 'duty_cycle'
 194:    set bit '$fmtd_2_isLeadingZero'
 195:    let var '$scratch' := 100
 196:    let var '$charToUart' := '$fmtd_1_convertState' / '$scratch'
 197:    let var '$scratch' := '$scratch' * '$charToUart'
 198:    let var '$fmtd_1_convertState' := '$fmtd_1_convertState' - '$scratch'
 199:    let var '$scratch' := 48
 200:    let var '$charToUart' := '$charToUart' + '$scratch'
 201:    if '$scratch' == '$charToUart' {
 202:        if '$fmtd_2_isLeadingZero' {
 203:            let var '$charToUart' := 32
 204:        }
 205:    } else {
 206:        clear bit '$fmtd_2_isLeadingZero'
 207:    }
 208:}
 209:let var '$scratch' := 17
 210:clear bit '$scratch'
 211:if '$scratch' == '$seqScratch' {
 212:    set bit '$scratch'
 213:}
 214:if '$scratch' {
 215:    let var '$scratch' := 10
 216:    let var '$charToUart' := '$fmtd_1_convertState' / '$scratch'
 217:    let var '$scratch' := '$scratch' * '$charToUart'
 218:    let var '$fmtd_1_convertState' := '$fmtd_1_convertState' - '$scratch'
 219:    let var '$scratch' := 48
 220:    let var '$charToUart' := '$charToUart' + '$scratch'
 221:    if '$scratch' == '$charToUart' {
 222:        if '$fmtd_2_isLeadingZero' {
 223:            let var '$charToUart' := 32
 224:        }
 225:    } else {
 226:        clear bit '$fmtd_2_isLeadingZero'
 227:    }
 228:}
 229:let var '$scratch' := 18
 230:clear bit '$scratch'
 231:if '$scratch' == '$seqScratch' {
 232:    set bit '$scratch'
 233:}
 234:if '$scratch' {
 235:    let var '$scratch' := 1
 236:    let var '$charToUart' := '$fmtd_1_convertState' / '$scratch'
 237:    let var '$scratch' := '$scratch' * '$charToUart'
 238:    let var '$fmtd_1_convertState' := '$fmtd_1_convertState' - '$scratch'
 239:    let var '$scratch' := 48
 240:    let var '$charToUart' := '$charToUart' + '$scratch'
 241:}
 242:let var '$scratch' := 19
 243:if '$scratch' == '$seqScratch' {
 244:    let var '$charToUart' := 37
 245:}
 246:let var '$scratch' := 20
 247:if '$scratch' == '$seqScratch' {
 248:    let var '$charToUart' := 13
 249:}
 250:let var '$scratch' := 21
 251:if '$scratch' == '$seqScratch' {
 252:    let var '$charToUart' := 10
 253:}
 254:if '$seqScratch' < '0' {
 255:} else {
 256:    if '$fmtd_3_doSend' {
 257:        uart send from '$charToUart[+0]'
 258:        increment '$fmtd_0_seq'
 259:    }
 260:}
 261:clear bit '$rung_top'
 262:if '$fmtd_0_seq' < '22' {
 263:    if '$fmtd_3_doSend' {
 264:        set bit '$rung_top'
 265:    }
 266:} else {
 267:    clear bit '$fmtd_3_doSend'
 268:}
 270:# ] finish series
 271:# 
 272:# ======= START RUNG 5 =======
 273:LabelRung5:
 274:
 275:set bit '$rung_top'
 277:# start series [
 278:# ELEM_SET_PWM
 279:if '$rung_top' {
 280:    set pwm 'duty_cycle' % 10000 Hz out 'PWMoutpin'
 281:    set bit '$PWMoutpin'
 282:}
 284:# ] finish series
 285:LabelRung6:
 286:
 287:# Latest INT_OP here
